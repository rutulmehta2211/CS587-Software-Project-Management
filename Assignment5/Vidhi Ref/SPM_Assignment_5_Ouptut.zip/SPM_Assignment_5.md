```python
# SPM_Assignment_5 
# Name :Rupa Rajendran
# Student ID:A20460455 
```


```python
import warnings
warnings.filterwarnings('ignore')

import os
from datetime import date
import dateutil.relativedelta

import pandas as pd                                    # panda's nickname is pd

import numpy as np                                     # numpy as np

from pandas import DataFrame, Series                   # for convenience

import matplotlib.pyplot as plt

%matplotlib inline

import pandas as pd

from fbprophet import Prophet

import statsmodels
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.tsa.seasonal import seasonal_decompose
from datetime import datetime

import tensorflow as tf
from tensorflow.contrib.timeseries.python.timeseries import  NumpyReader
import tensorflow.python.util.deprecation as deprecation
deprecation._PRINT_DEPRECATION_WARNINGS = False
import time
```


```python
#load data.
df = pd.read_csv('issues.csv')
print(df)

```

          issue_number OriginationPhase DetectionPhase     Category  Priority  \
    0                1     Requirements         Coding          Bug  Critical   
    1                2           Design        Testing  Enhancement      High   
    2                3     Requirements         Design      Inquiry       Low   
    3                4          Testing          Field          Bug      High   
    4                5    Documentation          Field  Enhancement     Major   
    ...            ...              ...            ...          ...       ...   
    1995          1996           Design         Coding      Inquiry       Low   
    1996          1997          Testing          Field          Bug    Medium   
    1997          1998    Documentation          Field  Enhancement     Major   
    1998          1999           Design         Coding      Inquiry      High   
    1999          2000           Design         Coding      Inquiry      High   
    
                 Status  created_at   closed_at   Author  
    0          Approved   2-24-2017         NaN    Smith  
    1          Approved   2-25-2017         NaN      Roy  
    2          Rejected   2-26-2017  03-07-2017    Linda  
    3         Completed   2-27-2017  03-08-2017      Kim  
    4     pendingReview   2-28-2017         NaN    James  
    ...             ...         ...         ...      ...  
    1995       Rejected  06-06-2017  08-04-2017  Zachary  
    1996      Completed  06-07-2017         NaN   Tamara  
    1997       Rejected  06-08-2017         NaN     Eric  
    1998  pendingReview   4-14-2017         NaN  Lindsey  
    1999      Completed  06-10-2017         NaN     John  
    
    [2000 rows x 9 columns]
    


```python
df.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>issue_number</th>
      <th>OriginationPhase</th>
      <th>DetectionPhase</th>
      <th>Category</th>
      <th>Priority</th>
      <th>Status</th>
      <th>created_at</th>
      <th>closed_at</th>
      <th>Author</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1995</th>
      <td>1996</td>
      <td>Design</td>
      <td>Coding</td>
      <td>Inquiry</td>
      <td>Low</td>
      <td>Rejected</td>
      <td>06-06-2017</td>
      <td>08-04-2017</td>
      <td>Zachary</td>
    </tr>
    <tr>
      <th>1996</th>
      <td>1997</td>
      <td>Testing</td>
      <td>Field</td>
      <td>Bug</td>
      <td>Medium</td>
      <td>Completed</td>
      <td>06-07-2017</td>
      <td>NaN</td>
      <td>Tamara</td>
    </tr>
    <tr>
      <th>1997</th>
      <td>1998</td>
      <td>Documentation</td>
      <td>Field</td>
      <td>Enhancement</td>
      <td>Major</td>
      <td>Rejected</td>
      <td>06-08-2017</td>
      <td>NaN</td>
      <td>Eric</td>
    </tr>
    <tr>
      <th>1998</th>
      <td>1999</td>
      <td>Design</td>
      <td>Coding</td>
      <td>Inquiry</td>
      <td>High</td>
      <td>pendingReview</td>
      <td>4-14-2017</td>
      <td>NaN</td>
      <td>Lindsey</td>
    </tr>
    <tr>
      <th>1999</th>
      <td>2000</td>
      <td>Design</td>
      <td>Coding</td>
      <td>Inquiry</td>
      <td>High</td>
      <td>Completed</td>
      <td>06-10-2017</td>
      <td>NaN</td>
      <td>John</td>
    </tr>
  </tbody>
</table>
</div>




```python
DailyIssue = df.groupby(['created_at']).created_at.count()
DailyIssue.plot(figsize= (25, 10))
#Data = DataFrame(DailyIssue)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fbf17aab750>




![png](output_4_1.png)



```python
df1 = df.groupby(['created_at'], as_index = False).count()
dataFrame = df1[['created_at','issue_number']]
dataFrame.columns = ['ds', 'y']
dataFrame
dataFrame.to_csv (r'github_data.csv', index = None, header=True) 

```


```python
#facebook prophet
dataFrame = pd.read_csv('github_data.csv')
m = Prophet()
m.fit(dataFrame)
```

    INFO:fbprophet:Disabling yearly seasonality. Run prophet with yearly_seasonality=True to override this.
    INFO:fbprophet:Disabling daily seasonality. Run prophet with daily_seasonality=True to override this.
    




    <fbprophet.forecaster.Prophet at 0x7fbf1958f450>




```python
#facebook
#make predict
future = m.make_future_dataframe(periods=365)
future.tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ds</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>648</th>
      <td>2018-12-18</td>
    </tr>
    <tr>
      <th>649</th>
      <td>2018-12-19</td>
    </tr>
    <tr>
      <th>650</th>
      <td>2018-12-20</td>
    </tr>
    <tr>
      <th>651</th>
      <td>2018-12-21</td>
    </tr>
    <tr>
      <th>652</th>
      <td>2018-12-22</td>
    </tr>
  </tbody>
</table>
</div>




```python
#facebook prophet
forecast = m.predict(future)
forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ds</th>
      <th>yhat</th>
      <th>yhat_lower</th>
      <th>yhat_upper</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>648</th>
      <td>2018-12-18</td>
      <td>-8.748293</td>
      <td>-20.096483</td>
      <td>1.412438</td>
    </tr>
    <tr>
      <th>649</th>
      <td>2018-12-19</td>
      <td>-8.940750</td>
      <td>-19.208459</td>
      <td>1.305377</td>
    </tr>
    <tr>
      <th>650</th>
      <td>2018-12-20</td>
      <td>-8.651966</td>
      <td>-19.632815</td>
      <td>1.430183</td>
    </tr>
    <tr>
      <th>651</th>
      <td>2018-12-21</td>
      <td>-8.558134</td>
      <td>-19.540155</td>
      <td>2.256645</td>
    </tr>
    <tr>
      <th>652</th>
      <td>2018-12-22</td>
      <td>-9.372622</td>
      <td>-19.922845</td>
      <td>0.577500</td>
    </tr>
  </tbody>
</table>
</div>




```python
#facebook prophet
forcast_fig1 = m.plot(forecast)
```


![png](output_9_0.png)



```python
#facebook prophet
forcast_fig2 = m.plot_components(forecast)
```


![png](output_10_0.png)



```python
#  i) Plot in Bar Chart the total number of issues created every day
issues = df.groupby(df.created_at).count()
issues.plot.bar(figsize = (25,10))


# ii. Plot in Bar Chart the total number of issues created everyday and originated in Design phase
issues = df[df.OriginationPhase=="Design"].groupby(df.created_at).count()
issues.plot.bar(figsize = (25,10))

# iii. Plot in Stacked Bar Chart the total number of issues based on their priorities created for every originating phase
plot3=df.groupby(['OriginationPhase','Priority']).count().unstack('Priority').fillna(0)
plot3['issue_number'].plot.bar(stacked=True)


# iv. Plot in Bar Chart the total number of issues closed in every day for every DetectionPhase that have labels (Category:Bug,Priority:Critical, Status:Completed)
plot4 = df[(df['Category']=="Bug") & (df['Priority']=='Critical') & (df['Status']=='Completed')].groupby(['DetectionPhase','closed_at']).count().unstack('closed_at').fillna(0)
plot4['issue_number'].plot.bar(title="Bar chart for every detection phase")


# v. Plot in Pivot Chart the total number of issue status created for every OriginationPhase (group by originating phase)
plot5 = df.pivot_table(values='issue_number',index='OriginationPhase',columns='Status',aggfunc=lambda x: len(x)).fillna(0)
ax=plot5.plot.bar(title="Pivot Chart for every OriginationPhase")
ax.legend(loc="upper left",bbox_to_anchor=(1,1))


# vi. Plot in Control Chart for the total number of Critical issues created every week and originated in Design phase. Your Control chart must plot/show the UCL (Upper Control Limit) and LCL (Lower Control Limit)

plot6 = (df[(df['Priority']=='Critical') & (df['OriginationPhase']=='Design')].groupby(pd.to_datetime(df.created_at).dt.to_period("W")).count()).iloc[:,2]
ax=plot6.plot.bar(figsize=(25,10))
ucl = np.mean(plot6.values)+3*np.std(plot6.values)
print(ucl)
lcl = np.mean(plot6.values)-3*np.std(plot6.values)
if lcl<0:
    lcl=0
print(lcl)

ax.hlines(ucl, ax.get_xticks().min(), ax.get_xticks().max(), linestyle='--', color='blue')
ax.hlines(lcl, ax.get_xticks().min(), ax.get_xticks().max(), linestyle='--', color='blue')
```

    33.38710551828214
    0
    




    <matplotlib.collections.LineCollection at 0x7fbf1eee3290>




![png](output_11_2.png)



![png](output_11_3.png)



![png](output_11_4.png)



![png](output_11_5.png)



![png](output_11_6.png)



```python
# 1. The day of the weeek maximum number of issues created

from datetime import date

#import calender
def most_num_of_issues_created(dataFrame):
    data = (dataFrame.groupby(['created_at']).count().reset_index()).sort_values('issue_number', ascending=False).head(1).iloc[0]['created_at']
    return data

most_issues_created = most_num_of_issues_created(df)

def convert(param):
    ans = datetime.date(pd.to_datetime(param))
    return ans.strftime("%A")

print("Day of week with max num of created_issues = ", most_issues_created, convert(most_issues_created))
```

    Day of week with max num of created_issues =  03-06-2017 Monday
    


```python
# 2. The day of the week maximum number of issues closed

from datetime import date

#import calender
def most_num_of_issues_closed(dataframe):
    data = (dataframe.groupby(['closed_at']).count().reset_index()).sort_values('issue_number', ascending=False).head(1).iloc[0]['closed_at']
    return data

max_issues_closed = most_num_of_issues_closed(df)


def convert(param):
    ans = datetime.date(pd.to_datetime(param))
    return ans.strftime("%A")

print("Day of week with max num of closed_issues = ",max_issues_closed, convert(max_issues_closed))
```

    Day of week with max num of closed_issues =  03-10-2017 Friday
    


```python
#3. the month of the year that has maximum number of issues closed

# Adding new column closed_month_year to new dataframes
df['closed_month_year'] = pd.to_datetime(df['closed_at']).dt.to_period('M')

month_year_max_issues_closed = df.groupby('closed_month_year').count()['issue_number'].idxmax(axis=0, skipna = True)

print("The month of the year that has maximum number of issues :",month_year_max_issues_closed.strftime('%B %F'))
```

    The month of the year that has maximum number of issues : March 2017
    


```python
#4. Plot the created issues forecast by calling the Prophet.plot method and passing in your forecast dataframe
def predict_plot(file):
    m = Prophet(yearly_seasonality=True, daily_seasonality=True)
    df = pd.read_csv(file)
    df_created = df['created_at'].value_counts().rename_axis('ds').reset_index(name='y')
    m.fit(df_created)
    future = m.make_future_dataframe(periods=200)
    forecast = m.predict(future)
    fig1 = m.plot(forecast)
    
predict_plot('issues.csv')

```


![png](output_15_0.png)



```python
#5. Plot the closed issues forecast; use the Prophet.plot_components method. By default you’ll see the trend, yearly seasonality, and weekly seasonality of the time series. If you include holidays, you’ll see those here, too.

def predict_plot_closed(file):
    m = Prophet(yearly_seasonality=True, daily_seasonality=True)
    df = pd.read_csv(file)
    df_closed = df['closed_at'].value_counts().rename_axis('ds').reset_index(name='y')
    m.fit(df_closed)
    future = m.make_future_dataframe(periods=365)
    forecast = m.predict(future)
    fig1 = m.plot_components(forecast)
    
predict_plot_closed('issues.csv')
```


![png](output_16_0.png)



```python
#statsmodel
issuesdf = pd.read_csv('issues.csv')
df = pd.read_csv('github_data.csv')
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ds</th>
      <th>y</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>01-05-2017</td>
      <td>8</td>
    </tr>
    <tr>
      <th>1</th>
      <td>01-06-2017</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>01-07-2017</td>
      <td>8</td>
    </tr>
    <tr>
      <th>3</th>
      <td>01-08-2017</td>
      <td>8</td>
    </tr>
    <tr>
      <th>4</th>
      <td>01-09-2017</td>
      <td>8</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>283</th>
      <td>9-26-2017</td>
      <td>1</td>
    </tr>
    <tr>
      <th>284</th>
      <td>9-27-2017</td>
      <td>1</td>
    </tr>
    <tr>
      <th>285</th>
      <td>9-28-2017</td>
      <td>1</td>
    </tr>
    <tr>
      <th>286</th>
      <td>9-29-2017</td>
      <td>1</td>
    </tr>
    <tr>
      <th>287</th>
      <td>9-30-2017</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>288 rows × 2 columns</p>
</div>




```python
df.set_index('ds')
predict = sm.tsa.seasonal_decompose(df.index, freq=8)
figure = predict.plot()
figure.set_size_inches(15, 8)
```


![png](output_18_0.png)



```python
df2 = df
model = sm.tsa.ARIMA(df2['y'].iloc[1:], order = (1, 0, 0))
results = model.fit()
df2['forecast'] = results.fittedvalues
df2[['y', 'forecast']].plot(figsize=(15,8))


```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fbf20ba4fd0>




![png](output_19_1.png)



```python
# 1. The day of the weeek maximum number of issues created : STATSMODEL

from datetime import date

def most_num_of_issues_created(dataframe):
    data = (dataframe.groupby(['created_at']).count().reset_index()).sort_values('issue_number', ascending=False).head(1).iloc[0]['created_at']
    return data

most_issues_created = most_num_of_issues_created(issuesdf) 

def convert(param):
    ans = datetime.date(pd.to_datetime(param)) 
    return ans.strftime("%A")

print("Day of week with max number of created_issues = ",most_issues_created, convert(most_issues_created)) 
      
```

    Day of week with max number of created_issues =  03-06-2017 Monday
    


```python
# 2. The day of the week maximum number of issues closed : STATSMODEL

def most_num_of_issues_closed(dataframe):
    data = (dataframe.groupby(['closed_at']).count().reset_index()).sort_values('issue_number', ascending=False).head(1).iloc[0]['closed_at']
    return data

max_issues_closed = most_num_of_issues_closed(issuesdf)

def convert(param):
    ans = datetime.date(pd.to_datetime(param)) 
    return ans.strftime("%A")
print("Day of week with max num of closed_issues",max_issues_closed, convert(max_issues_closed) )
```

    Day of week with max num of closed_issues 03-10-2017 Friday
    


```python
#3. the month of the year that has maximum number of issues closed : STATSMODEL
issuesdf['closed_month_year'] = pd.to_datetime(issuesdf['closed_at']).dt.to_period ('M')

max_issues_closed = issuesdf.groupby('closed_month_year').count()['issue_number'].idxmax(axis=0, skipna = True)

print("The month of the year that has maximum number of issues closed :", max_issues_closed.strftime('%B %F'))
```

    The month of the year that has maximum number of issues closed : March 2017
    


```python
#4. Plot the created issues forecast: STATSMODEL

from pandas import read_csv
#Statsmodel ii.4 Plot the created issues import tensorflow as tf
from pandas import datetime
from matplotlib import pyplot
from statsmodels.tsa.arima_model import ARIMA
from sklearn.metrics import mean_squared_error
from statsmodels.tsa.seasonal import seasonal_decompose

def parse_date(x): 
    print(x)
    return datetime.strptime(x, '%m-%d-%Y')

def stat_fun_1(series):
    X = series.values
    size = int(len(X) * 0.66)
    train, test = X[0:size], X[size:len(X)] 
    history = [x for x in train] 
    predictions_data = list()
    for t in range(len(test)):
        model = ARIMA(history, order=(1,0,0)) 
        model_fit = model.fit(disp=0)
        output = model_fit.forecast()
        yhat = output[0] 
        predictions_data.append(yhat)
        obs = test[t]
        history.append(obs)
        #print('predicted=%f, expected=%f' % (yhat, obs))
    error = mean_squared_error(test, predictions_data) 
    print('Test MSE: %.3f' % error)
    # plot
    plt.plot(test)
    plt.plot(predictions_data, color='red')
    plt.show()
    result = seasonal_decompose(list(predictions_data), model='additive', freq=1) 
    result.plot()
    plt.show()
    
def statsmodel_dataframe_created(temp_df):
    b = temp_df.groupby(['created_at'])['created_at'] 
    b1 = b.describe()
    temp = pd.DataFrame()
    temp = b1[['top', 'count']]
    temp.columns = ['ds', 'y']
    return temp

sm_df = pd.DataFrame(statsmodel_dataframe_created(issuesdf)) 
sm_df.to_csv('created_issues_stat.csv', sep = ',', encoding = 'utf-8', index = False) 

#Plotting 
series = read_csv('created_issues_stat.csv', header=0, parse_dates=[0], index_col=0, squeeze=True, date_parser=parse_date)
stat_fun_1(series)
```

    ['01-05-2017' '01-06-2017' '01-07-2017' '01-08-2017' '01-09-2017'
     '01-10-2017' '01-11-2017' '01-12-2017' '02-06-2017' '02-07-2017'
     '02-08-2017' '02-09-2017' '02-10-2017' '02-11-2017' '02-12-2017'
     '03-01-2017' '03-02-2017' '03-03-2017' '03-04-2017' '03-05-2017'
     '03-06-2017' '03-07-2017' '03-08-2017' '03-09-2017' '03-10-2017'
     '03-11-2017' '03-12-2017' '04-05-2017' '04-06-2017' '04-07-2017'
     '04-08-2017' '04-09-2017' '04-10-2017' '04-11-2017' '04-12-2017'
     '05-03-2017' '05-04-2017' '05-05-2017' '05-06-2017' '05-07-2017'
     '05-08-2017' '05-09-2017' '05-10-2017' '05-11-2017' '05-12-2017'
     '06-05-2017' '06-06-2017' '06-07-2017' '06-08-2017' '06-09-2017'
     '06-10-2017' '06-11-2017' '06-12-2017' '07-01-2017' '07-02-2017'
     '07-03-2017' '07-04-2017' '07-05-2017' '07-06-2017' '07-07-2017'
     '07-08-2017' '07-09-2017' '07-10-2017' '07-11-2017' '07-12-2017'
     '08-01-2017' '08-02-2017' '08-03-2017' '08-04-2017' '08-05-2017'
     '08-06-2017' '08-07-2017' '08-08-2017' '08-09-2017' '08-10-2017'
     '08-11-2017' '08-12-2017' '09-01-2017' '09-02-2017' '09-12-2017'
     '1-13-2017' '1-14-2017' '1-15-2017' '1-16-2017' '1-17-2017' '1-18-2017'
     '1-19-2017' '1-20-2017' '1-21-2017' '1-22-2017' '10-01-2017' '10-02-2017'
     '10-03-2017' '10-04-2017' '10-05-2017' '10-06-2017' '10-07-2017'
     '10-08-2017' '10-09-2017' '10-10-2017' '10-11-2017' '10-12-2017'
     '10-13-2017' '10-14-2017' '10-15-2017' '10-16-2017' '10-17-2017'
     '10-18-2017' '10-19-2017' '10-20-2017' '10-21-2017' '10-22-2017'
     '10-23-2017' '10-24-2017' '10-25-2017' '10-26-2017' '10-27-2017'
     '10-28-2017' '10-29-2017' '10-30-2017' '11-01-2017' '11-02-2017'
     '11-03-2017' '11-04-2017' '11-05-2017' '11-06-2017' '11-07-2017'
     '11-08-2017' '11-09-2017' '11-10-2017' '11-11-2017' '11-12-2017'
     '11-13-2017' '11-14-2017' '11-15-2017' '11-16-2017' '11-17-2017'
     '11-18-2017' '11-19-2017' '11-20-2017' '11-21-2017' '11-22-2017'
     '11-23-2017' '11-24-2017' '11-25-2017' '11-26-2017' '11-27-2017'
     '11-28-2017' '11-29-2017' '11-30-2017' '12-01-2017' '12-02-2017'
     '12-03-2017' '12-04-2017' '12-05-2017' '12-06-2017' '12-07-2017'
     '12-08-2017' '12-09-2017' '12-10-2017' '12-11-2017' '12-12-2017'
     '12-13-2017' '12-14-2017' '12-15-2017' '12-16-2017' '12-17-2017'
     '12-18-2017' '12-19-2017' '12-20-2017' '12-21-2017' '12-22-2017'
     '2-13-2017' '2-14-2017' '2-15-2017' '2-16-2017' '2-17-2017' '2-18-2017'
     '2-19-2017' '2-20-2017' '2-21-2017' '2-22-2017' '2-23-2017' '2-24-2017'
     '2-25-2017' '2-26-2017' '2-27-2017' '2-28-2017' '3-13-2017' '3-14-2017'
     '3-15-2017' '3-16-2017' '3-17-2017' '3-18-2017' '3-19-2017' '3-20-2017'
     '4-13-2017' '4-14-2017' '4-15-2017' '4-16-2017' '4-17-2017' '4-18-2017'
     '4-19-2017' '4-20-2017' '4-21-2017' '4-22-2017' '5-13-2017' '5-14-2017'
     '5-15-2017' '5-16-2017' '5-17-2017' '5-18-2017' '5-19-2017' '5-20-2017'
     '5-21-2017' '5-22-2017' '5-23-2017' '5-24-2017' '5-25-2017' '5-26-2017'
     '5-27-2017' '5-28-2017' '6-13-2017' '6-14-2017' '6-15-2017' '6-16-2017'
     '6-17-2017' '6-18-2017' '6-19-2017' '6-20-2017' '6-21-2017' '6-22-2017'
     '6-23-2017' '6-24-2017' '6-25-2017' '6-26-2017' '6-27-2017' '6-28-2017'
     '7-13-2017' '7-14-2017' '7-15-2017' '7-16-2017' '7-17-2017' '7-18-2017'
     '7-19-2017' '7-20-2017' '7-21-2017' '7-22-2017' '7-23-2017' '7-24-2017'
     '7-25-2017' '8-13-2017' '8-14-2017' '8-15-2017' '8-16-2017' '8-17-2017'
     '8-18-2017' '8-19-2017' '8-20-2017' '8-21-2017' '8-22-2017' '8-23-2017'
     '8-24-2017' '8-25-2017' '8-26-2017' '8-27-2017' '8-28-2017' '8-29-2017'
     '8-30-2017' '8-31-2017' '9-13-2017' '9-14-2017' '9-15-2017' '9-16-2017'
     '9-17-2017' '9-18-2017' '9-19-2017' '9-20-2017' '9-21-2017' '9-22-2017'
     '9-23-2017' '9-24-2017' '9-25-2017' '9-26-2017' '9-27-2017' '9-28-2017'
     '9-29-2017' '9-30-2017']
    01-05-2017
    01-06-2017
    01-07-2017
    01-08-2017
    01-09-2017
    01-10-2017
    01-11-2017
    01-12-2017
    02-06-2017
    02-07-2017
    02-08-2017
    02-09-2017
    02-10-2017
    02-11-2017
    02-12-2017
    03-01-2017
    03-02-2017
    03-03-2017
    03-04-2017
    03-05-2017
    03-06-2017
    03-07-2017
    03-08-2017
    03-09-2017
    03-10-2017
    03-11-2017
    03-12-2017
    04-05-2017
    04-06-2017
    04-07-2017
    04-08-2017
    04-09-2017
    04-10-2017
    04-11-2017
    04-12-2017
    05-03-2017
    05-04-2017
    05-05-2017
    05-06-2017
    05-07-2017
    05-08-2017
    05-09-2017
    05-10-2017
    05-11-2017
    05-12-2017
    06-05-2017
    06-06-2017
    06-07-2017
    06-08-2017
    06-09-2017
    06-10-2017
    06-11-2017
    06-12-2017
    07-01-2017
    07-02-2017
    07-03-2017
    07-04-2017
    07-05-2017
    07-06-2017
    07-07-2017
    07-08-2017
    07-09-2017
    07-10-2017
    07-11-2017
    07-12-2017
    08-01-2017
    08-02-2017
    08-03-2017
    08-04-2017
    08-05-2017
    08-06-2017
    08-07-2017
    08-08-2017
    08-09-2017
    08-10-2017
    08-11-2017
    08-12-2017
    09-01-2017
    09-02-2017
    09-12-2017
    1-13-2017
    1-14-2017
    1-15-2017
    1-16-2017
    1-17-2017
    1-18-2017
    1-19-2017
    1-20-2017
    1-21-2017
    1-22-2017
    10-01-2017
    10-02-2017
    10-03-2017
    10-04-2017
    10-05-2017
    10-06-2017
    10-07-2017
    10-08-2017
    10-09-2017
    10-10-2017
    10-11-2017
    10-12-2017
    10-13-2017
    10-14-2017
    10-15-2017
    10-16-2017
    10-17-2017
    10-18-2017
    10-19-2017
    10-20-2017
    10-21-2017
    10-22-2017
    10-23-2017
    10-24-2017
    10-25-2017
    10-26-2017
    10-27-2017
    10-28-2017
    10-29-2017
    10-30-2017
    11-01-2017
    11-02-2017
    11-03-2017
    11-04-2017
    11-05-2017
    11-06-2017
    11-07-2017
    11-08-2017
    11-09-2017
    11-10-2017
    11-11-2017
    11-12-2017
    11-13-2017
    11-14-2017
    11-15-2017
    11-16-2017
    11-17-2017
    11-18-2017
    11-19-2017
    11-20-2017
    11-21-2017
    11-22-2017
    11-23-2017
    11-24-2017
    11-25-2017
    11-26-2017
    11-27-2017
    11-28-2017
    11-29-2017
    11-30-2017
    12-01-2017
    12-02-2017
    12-03-2017
    12-04-2017
    12-05-2017
    12-06-2017
    12-07-2017
    12-08-2017
    12-09-2017
    12-10-2017
    12-11-2017
    12-12-2017
    12-13-2017
    12-14-2017
    12-15-2017
    12-16-2017
    12-17-2017
    12-18-2017
    12-19-2017
    12-20-2017
    12-21-2017
    12-22-2017
    2-13-2017
    2-14-2017
    2-15-2017
    2-16-2017
    2-17-2017
    2-18-2017
    2-19-2017
    2-20-2017
    2-21-2017
    2-22-2017
    2-23-2017
    2-24-2017
    2-25-2017
    2-26-2017
    2-27-2017
    2-28-2017
    3-13-2017
    3-14-2017
    3-15-2017
    3-16-2017
    3-17-2017
    3-18-2017
    3-19-2017
    3-20-2017
    4-13-2017
    4-14-2017
    4-15-2017
    4-16-2017
    4-17-2017
    4-18-2017
    4-19-2017
    4-20-2017
    4-21-2017
    4-22-2017
    5-13-2017
    5-14-2017
    5-15-2017
    5-16-2017
    5-17-2017
    5-18-2017
    5-19-2017
    5-20-2017
    5-21-2017
    5-22-2017
    5-23-2017
    5-24-2017
    5-25-2017
    5-26-2017
    5-27-2017
    5-28-2017
    6-13-2017
    6-14-2017
    6-15-2017
    6-16-2017
    6-17-2017
    6-18-2017
    6-19-2017
    6-20-2017
    6-21-2017
    6-22-2017
    6-23-2017
    6-24-2017
    6-25-2017
    6-26-2017
    6-27-2017
    6-28-2017
    7-13-2017
    7-14-2017
    7-15-2017
    7-16-2017
    7-17-2017
    7-18-2017
    7-19-2017
    7-20-2017
    7-21-2017
    7-22-2017
    7-23-2017
    7-24-2017
    7-25-2017
    8-13-2017
    8-14-2017
    8-15-2017
    8-16-2017
    8-17-2017
    8-18-2017
    8-19-2017
    8-20-2017
    8-21-2017
    8-22-2017
    8-23-2017
    8-24-2017
    8-25-2017
    8-26-2017
    8-27-2017
    8-28-2017
    8-29-2017
    8-30-2017
    8-31-2017
    9-13-2017
    9-14-2017
    9-15-2017
    9-16-2017
    9-17-2017
    9-18-2017
    9-19-2017
    9-20-2017
    9-21-2017
    9-22-2017
    9-23-2017
    9-24-2017
    9-25-2017
    9-26-2017
    9-27-2017
    9-28-2017
    9-29-2017
    9-30-2017
    Test MSE: 19.136
    


![png](output_23_1.png)



![png](output_23_2.png)



```python
#5. Plot the closed issues forecast : STATSMODEL

def statsmodel_dataframe_closed(temp_df):
    b = temp_df.groupby(['closed_at'])['closed_at'] 
    b1 = b.describe()
    temp = pd.DataFrame()
    temp = b1[['top', 'count']]
    temp.columns = ['ds', 'y']
    return temp


sm_df = pd.DataFrame(statsmodel_dataframe_closed(issuesdf))
sm_df.to_csv('closed_issues_stat_closed.csv', sep = ',', encoding = 'utf-8', index = False)

#plotting 
series = read_csv('closed_issues_stat_closed.csv', header=0, parse_dates=[0], index_col=0, squeeze=True, date_parser=parse_date)
stat_fun_1(series)
```

    ['02-12-2017' '03-03-2017' '03-04-2017' '03-07-2017' '03-08-2017'
     '03-09-2017' '03-10-2017' '03-11-2017' '03-12-2017' '04-02-2017'
     '04-03-2017' '04-05-2017' '04-06-2017' '04-09-2017' '04-10-2017'
     '04-12-2017' '06-03-2017' '06-05-2017' '06-06-2017' '06-08-2017'
     '06-09-2017' '06-11-2017' '06-12-2017' '07-02-2017' '07-03-2017'
     '07-05-2017' '07-06-2017' '07-07-2017' '07-08-2017' '07-09-2017'
     '07-10-2017' '07-12-2017' '08-01-2017' '08-02-2017' '08-03-2017'
     '08-04-2017' '08-05-2017' '08-07-2017' '08-08-2017' '08-09-2017'
     '08-10-2017' '08-11-2017' '09-01-2017' '09-02-2017' '09-03-2017'
     '09-04-2017' '09-05-2017' '09-06-2017' '09-07-2017' '09-08-2017'
     '09-09-2017' '09-10-2017' '09-11-2017' '09-12-2017' '10-01-2017'
     '10-02-2017' '10-03-2017' '10-05-2017' '10-06-2017' '10-07-2017'
     '10-08-2017' '10-10-2017' '10-13-2017' '10-14-2017' '10-15-2017'
     '10-18-2017' '10-19-2017' '10-20-2017' '10-21-2017' '10-22-2017'
     '10-23-2017' '10-24-2017' '10-25-2017' '10-26-2017' '10-27-2017'
     '10-28-2017' '10-29-2017' '10-30-2017' '11-02-2017' '11-04-2017'
     '11-05-2017' '11-06-2017' '11-07-2017' '11-08-2017' '11-09-2017'
     '11-10-2017' '11-11-2017' '11-12-2017' '11-13-2017' '11-14-2017'
     '11-15-2017' '11-16-2017' '11-17-2017' '11-19-2017' '11-20-2017'
     '11-21-2017' '11-22-2017' '11-23-2017' '11-24-2017' '11-25-2017'
     '11-26-2017' '11-27-2017' '11-28-2017' '11-29-2017' '11-30-2017'
     '12-01-2017' '12-02-2017' '12-03-2017' '12-04-2017' '12-05-2017'
     '12-06-2017' '12-07-2017' '12-08-2017' '12-09-2017' '12-10-2017'
     '12-11-2017' '12-12-2017' '12-13-2017' '12-14-2017' '12-15-2017'
     '12-16-2017' '12-17-2017' '12-18-2017' '12-19-2017' '12-20-2017'
     '12-21-2017' '12-22-2017' '12-23-2017' '12-24-2017' '12-25-2017'
     '12-26-2017' '12-27-2017' '2-15-2017' '2-18-2017' '3-13-2017' '3-14-2017'
     '3-15-2017' '3-16-2017' '3-17-2017' '3-18-2017' '3-19-2017' '3-20-2017'
     '3-21-2017' '3-22-2017' '3-23-2017' '3-24-2017' '3-25-2017' '3-26-2017'
     '3-28-2017' '3-29-2017' '3-30-2017' '4-13-2017' '4-14-2017' '5-13-2017'
     '5-14-2017' '5-20-2017' '5-21-2017' '5-25-2017' '5-26-2017' '6-14-2017'
     '6-19-2017' '6-20-2017' '6-22-2017' '6-23-2017' '6-24-2017' '6-26-2017'
     '6-28-2017' '6-29-2017' '7-13-2017' '7-14-2017' '7-16-2017' '7-17-2017'
     '7-18-2017' '7-19-2017' '7-21-2017' '7-22-2017' '7-24-2017' '7-26-2017'
     '7-28-2017' '7-29-2017' '7-30-2017' '7-31-2017' '8-13-2017' '8-14-2017'
     '8-15-2017' '8-16-2017' '8-17-2017' '8-18-2017' '8-19-2017' '8-20-2017'
     '8-21-2017' '8-22-2017' '8-23-2017' '8-24-2017' '8-25-2017' '8-26-2017'
     '8-27-2017' '8-28-2017' '8-29-2017' '8-30-2017' '8-31-2017' '9-13-2017'
     '9-14-2017' '9-15-2017' '9-16-2017' '9-17-2017' '9-18-2017' '9-19-2017'
     '9-20-2017' '9-21-2017' '9-22-2017' '9-23-2017' '9-26-2017' '9-27-2017'
     '9-28-2017' '9-29-2017' '9-30-2017']
    02-12-2017
    03-03-2017
    03-04-2017
    03-07-2017
    03-08-2017
    03-09-2017
    03-10-2017
    03-11-2017
    03-12-2017
    04-02-2017
    04-03-2017
    04-05-2017
    04-06-2017
    04-09-2017
    04-10-2017
    04-12-2017
    06-03-2017
    06-05-2017
    06-06-2017
    06-08-2017
    06-09-2017
    06-11-2017
    06-12-2017
    07-02-2017
    07-03-2017
    07-05-2017
    07-06-2017
    07-07-2017
    07-08-2017
    07-09-2017
    07-10-2017
    07-12-2017
    08-01-2017
    08-02-2017
    08-03-2017
    08-04-2017
    08-05-2017
    08-07-2017
    08-08-2017
    08-09-2017
    08-10-2017
    08-11-2017
    09-01-2017
    09-02-2017
    09-03-2017
    09-04-2017
    09-05-2017
    09-06-2017
    09-07-2017
    09-08-2017
    09-09-2017
    09-10-2017
    09-11-2017
    09-12-2017
    10-01-2017
    10-02-2017
    10-03-2017
    10-05-2017
    10-06-2017
    10-07-2017
    10-08-2017
    10-10-2017
    10-13-2017
    10-14-2017
    10-15-2017
    10-18-2017
    10-19-2017
    10-20-2017
    10-21-2017
    10-22-2017
    10-23-2017
    10-24-2017
    10-25-2017
    10-26-2017
    10-27-2017
    10-28-2017
    10-29-2017
    10-30-2017
    11-02-2017
    11-04-2017
    11-05-2017
    11-06-2017
    11-07-2017
    11-08-2017
    11-09-2017
    11-10-2017
    11-11-2017
    11-12-2017
    11-13-2017
    11-14-2017
    11-15-2017
    11-16-2017
    11-17-2017
    11-19-2017
    11-20-2017
    11-21-2017
    11-22-2017
    11-23-2017
    11-24-2017
    11-25-2017
    11-26-2017
    11-27-2017
    11-28-2017
    11-29-2017
    11-30-2017
    12-01-2017
    12-02-2017
    12-03-2017
    12-04-2017
    12-05-2017
    12-06-2017
    12-07-2017
    12-08-2017
    12-09-2017
    12-10-2017
    12-11-2017
    12-12-2017
    12-13-2017
    12-14-2017
    12-15-2017
    12-16-2017
    12-17-2017
    12-18-2017
    12-19-2017
    12-20-2017
    12-21-2017
    12-22-2017
    12-23-2017
    12-24-2017
    12-25-2017
    12-26-2017
    12-27-2017
    2-15-2017
    2-18-2017
    3-13-2017
    3-14-2017
    3-15-2017
    3-16-2017
    3-17-2017
    3-18-2017
    3-19-2017
    3-20-2017
    3-21-2017
    3-22-2017
    3-23-2017
    3-24-2017
    3-25-2017
    3-26-2017
    3-28-2017
    3-29-2017
    3-30-2017
    4-13-2017
    4-14-2017
    5-13-2017
    5-14-2017
    5-20-2017
    5-21-2017
    5-25-2017
    5-26-2017
    6-14-2017
    6-19-2017
    6-20-2017
    6-22-2017
    6-23-2017
    6-24-2017
    6-26-2017
    6-28-2017
    6-29-2017
    7-13-2017
    7-14-2017
    7-16-2017
    7-17-2017
    7-18-2017
    7-19-2017
    7-21-2017
    7-22-2017
    7-24-2017
    7-26-2017
    7-28-2017
    7-29-2017
    7-30-2017
    7-31-2017
    8-13-2017
    8-14-2017
    8-15-2017
    8-16-2017
    8-17-2017
    8-18-2017
    8-19-2017
    8-20-2017
    8-21-2017
    8-22-2017
    8-23-2017
    8-24-2017
    8-25-2017
    8-26-2017
    8-27-2017
    8-28-2017
    8-29-2017
    8-30-2017
    8-31-2017
    9-13-2017
    9-14-2017
    9-15-2017
    9-16-2017
    9-17-2017
    9-18-2017
    9-19-2017
    9-20-2017
    9-21-2017
    9-22-2017
    9-23-2017
    9-26-2017
    9-27-2017
    9-28-2017
    9-29-2017
    9-30-2017
    Test MSE: 19.384
    


![png](output_24_1.png)



![png](output_24_2.png)



```python
# Tensorflow
df = pd.read_csv('github_data.csv')
issuesdf = pd.read_csv('issues.csv')
```


```python
df['ds'] = df['ds'].astype('datetime64[ns]')
array = df.to_numpy()
x = np.array([time.mktime(i[0].timetuple()) for i in array])
y = np.array([i[1] for i in array])

```


```python
#get data for tensorflow
data = {
    tf.contrib.timeseries.TrainEvalFeatures.TIMES: x,
    tf.contrib.timeseries.TrainEvalFeatures.VALUES: y,
}
print (data)

reader = NumpyReader(data)

train_input_fn = tf.contrib.timeseries.RandomWindowInputFn(reader, batch_size = 40, window_size = 40)
ar = tf.contrib.timeseries.ARRegressor(
        periodicities=200, input_window_size=30, output_window_size=10,
        num_features=1,
        loss=tf.contrib.timeseries.ARModel.NORMAL_LIKELIHOOD_LOSS)
ar.train(input_fn=train_input_fn, steps=6000)
#train_op = optimizer.minimize(loss, global_step = tf.train.get_global_step())
```

    {'times': array([1.4835960e+09, 1.4836824e+09, 1.4837688e+09, 1.4838552e+09,
           1.4839416e+09, 1.4840280e+09, 1.4841144e+09, 1.4842008e+09,
           1.4863608e+09, 1.4864472e+09, 1.4865336e+09, 1.4866200e+09,
           1.4867064e+09, 1.4867928e+09, 1.4868792e+09, 1.4883480e+09,
           1.4884344e+09, 1.4885208e+09, 1.4886072e+09, 1.4886936e+09,
           1.4887800e+09, 1.4888664e+09, 1.4889528e+09, 1.4890392e+09,
           1.4891256e+09, 1.4892120e+09, 1.4892984e+09, 1.4913684e+09,
           1.4914548e+09, 1.4915412e+09, 1.4916276e+09, 1.4917140e+09,
           1.4918004e+09, 1.4918868e+09, 1.4919732e+09, 1.4937876e+09,
           1.4938740e+09, 1.4939604e+09, 1.4940468e+09, 1.4941332e+09,
           1.4942196e+09, 1.4943060e+09, 1.4943924e+09, 1.4944788e+09,
           1.4945652e+09, 1.4966388e+09, 1.4967252e+09, 1.4968116e+09,
           1.4968980e+09, 1.4969844e+09, 1.4970708e+09, 1.4971572e+09,
           1.4972436e+09, 1.4988852e+09, 1.4989716e+09, 1.4990580e+09,
           1.4991444e+09, 1.4992308e+09, 1.4993172e+09, 1.4994036e+09,
           1.4994900e+09, 1.4995764e+09, 1.4996628e+09, 1.4997492e+09,
           1.4998356e+09, 1.5015636e+09, 1.5016500e+09, 1.5017364e+09,
           1.5018228e+09, 1.5019092e+09, 1.5019956e+09, 1.5020820e+09,
           1.5021684e+09, 1.5022548e+09, 1.5023412e+09, 1.5024276e+09,
           1.5025140e+09, 1.5042420e+09, 1.5043284e+09, 1.5051924e+09,
           1.4842872e+09, 1.4843736e+09, 1.4844600e+09, 1.4845464e+09,
           1.4846328e+09, 1.4847192e+09, 1.4848056e+09, 1.4848920e+09,
           1.4849784e+09, 1.4850648e+09, 1.5068340e+09, 1.5069204e+09,
           1.5070068e+09, 1.5070932e+09, 1.5071796e+09, 1.5072660e+09,
           1.5073524e+09, 1.5074388e+09, 1.5075252e+09, 1.5076116e+09,
           1.5076980e+09, 1.5077844e+09, 1.5078708e+09, 1.5079572e+09,
           1.5080436e+09, 1.5081300e+09, 1.5082164e+09, 1.5083028e+09,
           1.5083892e+09, 1.5084756e+09, 1.5085620e+09, 1.5086484e+09,
           1.5087348e+09, 1.5088212e+09, 1.5089076e+09, 1.5089940e+09,
           1.5090804e+09, 1.5091668e+09, 1.5092532e+09, 1.5093396e+09,
           1.5095124e+09, 1.5095988e+09, 1.5096852e+09, 1.5097716e+09,
           1.5098580e+09, 1.5099480e+09, 1.5100344e+09, 1.5101208e+09,
           1.5102072e+09, 1.5102936e+09, 1.5103800e+09, 1.5104664e+09,
           1.5105528e+09, 1.5106392e+09, 1.5107256e+09, 1.5108120e+09,
           1.5108984e+09, 1.5109848e+09, 1.5110712e+09, 1.5111576e+09,
           1.5112440e+09, 1.5113304e+09, 1.5114168e+09, 1.5115032e+09,
           1.5115896e+09, 1.5116760e+09, 1.5117624e+09, 1.5118488e+09,
           1.5119352e+09, 1.5120216e+09, 1.5121080e+09, 1.5121944e+09,
           1.5122808e+09, 1.5123672e+09, 1.5124536e+09, 1.5125400e+09,
           1.5126264e+09, 1.5127128e+09, 1.5127992e+09, 1.5128856e+09,
           1.5129720e+09, 1.5130584e+09, 1.5131448e+09, 1.5132312e+09,
           1.5133176e+09, 1.5134040e+09, 1.5134904e+09, 1.5135768e+09,
           1.5136632e+09, 1.5137496e+09, 1.5138360e+09, 1.5139224e+09,
           1.4869656e+09, 1.4870520e+09, 1.4871384e+09, 1.4872248e+09,
           1.4873112e+09, 1.4873976e+09, 1.4874840e+09, 1.4875704e+09,
           1.4876568e+09, 1.4877432e+09, 1.4878296e+09, 1.4879160e+09,
           1.4880024e+09, 1.4880888e+09, 1.4881752e+09, 1.4882616e+09,
           1.4893812e+09, 1.4894676e+09, 1.4895540e+09, 1.4896404e+09,
           1.4897268e+09, 1.4898132e+09, 1.4898996e+09, 1.4899860e+09,
           1.4920596e+09, 1.4921460e+09, 1.4922324e+09, 1.4923188e+09,
           1.4924052e+09, 1.4924916e+09, 1.4925780e+09, 1.4926644e+09,
           1.4927508e+09, 1.4928372e+09, 1.4946516e+09, 1.4947380e+09,
           1.4948244e+09, 1.4949108e+09, 1.4949972e+09, 1.4950836e+09,
           1.4951700e+09, 1.4952564e+09, 1.4953428e+09, 1.4954292e+09,
           1.4955156e+09, 1.4956020e+09, 1.4956884e+09, 1.4957748e+09,
           1.4958612e+09, 1.4959476e+09, 1.4973300e+09, 1.4974164e+09,
           1.4975028e+09, 1.4975892e+09, 1.4976756e+09, 1.4977620e+09,
           1.4978484e+09, 1.4979348e+09, 1.4980212e+09, 1.4981076e+09,
           1.4981940e+09, 1.4982804e+09, 1.4983668e+09, 1.4984532e+09,
           1.4985396e+09, 1.4986260e+09, 1.4999220e+09, 1.5000084e+09,
           1.5000948e+09, 1.5001812e+09, 1.5002676e+09, 1.5003540e+09,
           1.5004404e+09, 1.5005268e+09, 1.5006132e+09, 1.5006996e+09,
           1.5007860e+09, 1.5008724e+09, 1.5009588e+09, 1.5026004e+09,
           1.5026868e+09, 1.5027732e+09, 1.5028596e+09, 1.5029460e+09,
           1.5030324e+09, 1.5031188e+09, 1.5032052e+09, 1.5032916e+09,
           1.5033780e+09, 1.5034644e+09, 1.5035508e+09, 1.5036372e+09,
           1.5037236e+09, 1.5038100e+09, 1.5038964e+09, 1.5039828e+09,
           1.5040692e+09, 1.5041556e+09, 1.5052788e+09, 1.5053652e+09,
           1.5054516e+09, 1.5055380e+09, 1.5056244e+09, 1.5057108e+09,
           1.5057972e+09, 1.5058836e+09, 1.5059700e+09, 1.5060564e+09,
           1.5061428e+09, 1.5062292e+09, 1.5063156e+09, 1.5064020e+09,
           1.5064884e+09, 1.5065748e+09, 1.5066612e+09, 1.5067476e+09]), 'values': array([ 8,  8,  8,  8,  8,  5,  8,  7,  3,  3,  3,  4,  4,  3,  3, 33, 47,
           52, 51, 55, 55, 35, 36, 36, 34, 26, 20,  2,  2,  2,  2,  6, 15, 25,
           30,  1,  1,  4,  4,  5,  4,  4,  8,  9,  9, 10, 11, 11, 14, 13, 14,
           13, 13,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  4,  6,  6,
            6,  8, 11, 11,  8,  8,  7,  8,  8,  1,  1,  1,  7,  7, 11, 11,  4,
            4,  5,  5,  5, 12,  2,  2,  1,  1,  1,  1,  2,  2,  2,  6,  6,  7,
            8,  8,  7,  7,  7,  7,  7,  5,  5,  5,  2,  2,  1,  1,  1,  1,  1,
            1,  2,  2,  2,  4,  4,  4,  4,  7,  7,  6,  5,  5,  8,  8, 10,  8,
            8,  8,  8,  9,  7,  7,  6,  7,  7,  3,  2,  2,  1,  1,  1,  2,  2,
            4,  3,  3,  3,  3,  4,  5,  5,  6,  4,  5,  4,  3,  3,  3,  4,  4,
            1,  1, 11,  5,  5,  5,  5,  6,  3,  3,  4,  4,  4,  5,  5,  2, 34,
           40,  8, 15, 15,  6, 21, 10,  8,  7, 32, 18,  2,  2,  2,  2,  2,  2,
            2,  2,  9,  7,  3,  3, 11, 11, 11, 14, 14,  7,  1,  1,  4,  4,  7,
            7, 13,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
            2,  2,  2, 11, 11, 11, 11, 11, 11,  4,  2,  1,  1,  8,  8,  8,  8,
            8,  8,  9,  9,  8,  8,  8,  8,  8,  8,  6,  5,  4,  3,  3,  1,  1,
            1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1])}
    INFO:tensorflow:Using default config.
    

    INFO:tensorflow:Using default config.
    

    WARNING:tensorflow:Using temporary folder as model directory: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz
    

    WARNING:tensorflow:Using temporary folder as model directory: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz
    

    INFO:tensorflow:Using config: {'_model_dir': '/var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz', '_tf_random_seed': None, '_save_summary_steps': 100, '_save_checkpoints_steps': None, '_save_checkpoints_secs': 600, '_session_config': allow_soft_placement: true
    graph_options {
      rewrite_options {
        meta_optimizer_iterations: ONE
      }
    }
    , '_keep_checkpoint_max': 5, '_keep_checkpoint_every_n_hours': 10000, '_log_step_count_steps': 100, '_train_distribute': None, '_device_fn': None, '_protocol': None, '_eval_distribute': None, '_experimental_distribute': None, '_experimental_max_worker_delay_secs': None, '_service': None, '_cluster_spec': <tensorflow.python.training.server_lib.ClusterSpec object at 0x7fbf01701e10>, '_task_type': 'worker', '_task_id': 0, '_global_id_in_cluster': 0, '_master': '', '_evaluation_master': '', '_is_chief': True, '_num_ps_replicas': 0, '_num_worker_replicas': 1}
    

    INFO:tensorflow:Using config: {'_model_dir': '/var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz', '_tf_random_seed': None, '_save_summary_steps': 100, '_save_checkpoints_steps': None, '_save_checkpoints_secs': 600, '_session_config': allow_soft_placement: true
    graph_options {
      rewrite_options {
        meta_optimizer_iterations: ONE
      }
    }
    , '_keep_checkpoint_max': 5, '_keep_checkpoint_every_n_hours': 10000, '_log_step_count_steps': 100, '_train_distribute': None, '_device_fn': None, '_protocol': None, '_eval_distribute': None, '_experimental_distribute': None, '_experimental_max_worker_delay_secs': None, '_service': None, '_cluster_spec': <tensorflow.python.training.server_lib.ClusterSpec object at 0x7fbf01701e10>, '_task_type': 'worker', '_task_id': 0, '_global_id_in_cluster': 0, '_master': '', '_evaluation_master': '', '_is_chief': True, '_num_ps_replicas': 0, '_num_worker_replicas': 1}
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02d82d90>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02d82d90>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02d82d90>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02d82d90>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02d82d90>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02d82d90>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Create CheckpointSaverHook.
    

    INFO:tensorflow:Create CheckpointSaverHook.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Saving checkpoints for 0 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt.
    

    INFO:tensorflow:Saving checkpoints for 0 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt.
    

    INFO:tensorflow:loss = 1.1742582, step = 1
    

    INFO:tensorflow:loss = 1.1742582, step = 1
    

    INFO:tensorflow:global_step/sec: 191.953
    

    INFO:tensorflow:global_step/sec: 191.953
    

    INFO:tensorflow:loss = 0.8935287, step = 101 (0.522 sec)
    

    INFO:tensorflow:loss = 0.8935287, step = 101 (0.522 sec)
    

    INFO:tensorflow:global_step/sec: 145.149
    

    INFO:tensorflow:global_step/sec: 145.149
    

    INFO:tensorflow:loss = 0.82280767, step = 201 (0.689 sec)
    

    INFO:tensorflow:loss = 0.82280767, step = 201 (0.689 sec)
    

    INFO:tensorflow:global_step/sec: 145.243
    

    INFO:tensorflow:global_step/sec: 145.243
    

    INFO:tensorflow:loss = 0.8279248, step = 301 (0.688 sec)
    

    INFO:tensorflow:loss = 0.8279248, step = 301 (0.688 sec)
    

    INFO:tensorflow:global_step/sec: 146.282
    

    INFO:tensorflow:global_step/sec: 146.282
    

    INFO:tensorflow:loss = 0.7996957, step = 401 (0.683 sec)
    

    INFO:tensorflow:loss = 0.7996957, step = 401 (0.683 sec)
    

    INFO:tensorflow:global_step/sec: 145.868
    

    INFO:tensorflow:global_step/sec: 145.868
    

    INFO:tensorflow:loss = 0.84899914, step = 501 (0.686 sec)
    

    INFO:tensorflow:loss = 0.84899914, step = 501 (0.686 sec)
    

    INFO:tensorflow:global_step/sec: 144.169
    

    INFO:tensorflow:global_step/sec: 144.169
    

    INFO:tensorflow:loss = 0.7898318, step = 601 (0.694 sec)
    

    INFO:tensorflow:loss = 0.7898318, step = 601 (0.694 sec)
    

    INFO:tensorflow:global_step/sec: 144.492
    

    INFO:tensorflow:global_step/sec: 144.492
    

    INFO:tensorflow:loss = 0.785343, step = 701 (0.692 sec)
    

    INFO:tensorflow:loss = 0.785343, step = 701 (0.692 sec)
    

    INFO:tensorflow:global_step/sec: 146.99
    

    INFO:tensorflow:global_step/sec: 146.99
    

    INFO:tensorflow:loss = 0.82011956, step = 801 (0.680 sec)
    

    INFO:tensorflow:loss = 0.82011956, step = 801 (0.680 sec)
    

    INFO:tensorflow:global_step/sec: 144.934
    

    INFO:tensorflow:global_step/sec: 144.934
    

    INFO:tensorflow:loss = 0.8073518, step = 901 (0.690 sec)
    

    INFO:tensorflow:loss = 0.8073518, step = 901 (0.690 sec)
    

    INFO:tensorflow:global_step/sec: 143.217
    

    INFO:tensorflow:global_step/sec: 143.217
    

    INFO:tensorflow:loss = 0.82479894, step = 1001 (0.698 sec)
    

    INFO:tensorflow:loss = 0.82479894, step = 1001 (0.698 sec)
    

    INFO:tensorflow:global_step/sec: 143.992
    

    INFO:tensorflow:global_step/sec: 143.992
    

    INFO:tensorflow:loss = 0.8285986, step = 1101 (0.694 sec)
    

    INFO:tensorflow:loss = 0.8285986, step = 1101 (0.694 sec)
    

    INFO:tensorflow:global_step/sec: 146.182
    

    INFO:tensorflow:global_step/sec: 146.182
    

    INFO:tensorflow:loss = 0.81110096, step = 1201 (0.684 sec)
    

    INFO:tensorflow:loss = 0.81110096, step = 1201 (0.684 sec)
    

    INFO:tensorflow:global_step/sec: 143.823
    

    INFO:tensorflow:global_step/sec: 143.823
    

    INFO:tensorflow:loss = 0.70926404, step = 1301 (0.695 sec)
    

    INFO:tensorflow:loss = 0.70926404, step = 1301 (0.695 sec)
    

    INFO:tensorflow:global_step/sec: 148.103
    

    INFO:tensorflow:global_step/sec: 148.103
    

    INFO:tensorflow:loss = 0.73773336, step = 1401 (0.675 sec)
    

    INFO:tensorflow:loss = 0.73773336, step = 1401 (0.675 sec)
    

    INFO:tensorflow:global_step/sec: 136.631
    

    INFO:tensorflow:global_step/sec: 136.631
    

    INFO:tensorflow:loss = 0.7261714, step = 1501 (0.732 sec)
    

    INFO:tensorflow:loss = 0.7261714, step = 1501 (0.732 sec)
    

    INFO:tensorflow:global_step/sec: 145.135
    

    INFO:tensorflow:global_step/sec: 145.135
    

    INFO:tensorflow:loss = 0.74378425, step = 1601 (0.689 sec)
    

    INFO:tensorflow:loss = 0.74378425, step = 1601 (0.689 sec)
    

    INFO:tensorflow:global_step/sec: 145.46
    

    INFO:tensorflow:global_step/sec: 145.46
    

    INFO:tensorflow:loss = 0.733501, step = 1701 (0.687 sec)
    

    INFO:tensorflow:loss = 0.733501, step = 1701 (0.687 sec)
    

    INFO:tensorflow:global_step/sec: 143.063
    

    INFO:tensorflow:global_step/sec: 143.063
    

    INFO:tensorflow:loss = 0.71344876, step = 1801 (0.699 sec)
    

    INFO:tensorflow:loss = 0.71344876, step = 1801 (0.699 sec)
    

    INFO:tensorflow:global_step/sec: 144.91
    

    INFO:tensorflow:global_step/sec: 144.91
    

    INFO:tensorflow:loss = 0.70226383, step = 1901 (0.690 sec)
    

    INFO:tensorflow:loss = 0.70226383, step = 1901 (0.690 sec)
    

    INFO:tensorflow:global_step/sec: 146.765
    

    INFO:tensorflow:global_step/sec: 146.765
    

    INFO:tensorflow:loss = 0.771028, step = 2001 (0.681 sec)
    

    INFO:tensorflow:loss = 0.771028, step = 2001 (0.681 sec)
    

    INFO:tensorflow:global_step/sec: 146.201
    

    INFO:tensorflow:global_step/sec: 146.201
    

    INFO:tensorflow:loss = 0.7279149, step = 2101 (0.684 sec)
    

    INFO:tensorflow:loss = 0.7279149, step = 2101 (0.684 sec)
    

    INFO:tensorflow:global_step/sec: 145.12
    

    INFO:tensorflow:global_step/sec: 145.12
    

    INFO:tensorflow:loss = 0.7437529, step = 2201 (0.689 sec)
    

    INFO:tensorflow:loss = 0.7437529, step = 2201 (0.689 sec)
    

    INFO:tensorflow:global_step/sec: 144.663
    

    INFO:tensorflow:global_step/sec: 144.663
    

    INFO:tensorflow:loss = 0.73540145, step = 2301 (0.691 sec)
    

    INFO:tensorflow:loss = 0.73540145, step = 2301 (0.691 sec)
    

    INFO:tensorflow:global_step/sec: 142.353
    

    INFO:tensorflow:global_step/sec: 142.353
    

    INFO:tensorflow:loss = 0.7887724, step = 2401 (0.702 sec)
    

    INFO:tensorflow:loss = 0.7887724, step = 2401 (0.702 sec)
    

    INFO:tensorflow:global_step/sec: 144.88
    

    INFO:tensorflow:global_step/sec: 144.88
    

    INFO:tensorflow:loss = 0.80012554, step = 2501 (0.690 sec)
    

    INFO:tensorflow:loss = 0.80012554, step = 2501 (0.690 sec)
    

    INFO:tensorflow:global_step/sec: 145.696
    

    INFO:tensorflow:global_step/sec: 145.696
    

    INFO:tensorflow:loss = 0.67650855, step = 2601 (0.686 sec)
    

    INFO:tensorflow:loss = 0.67650855, step = 2601 (0.686 sec)
    

    INFO:tensorflow:global_step/sec: 144.841
    

    INFO:tensorflow:global_step/sec: 144.841
    

    INFO:tensorflow:loss = 0.7246661, step = 2701 (0.690 sec)
    

    INFO:tensorflow:loss = 0.7246661, step = 2701 (0.690 sec)
    

    INFO:tensorflow:global_step/sec: 145.002
    

    INFO:tensorflow:global_step/sec: 145.002
    

    INFO:tensorflow:loss = 0.78800786, step = 2801 (0.690 sec)
    

    INFO:tensorflow:loss = 0.78800786, step = 2801 (0.690 sec)
    

    INFO:tensorflow:global_step/sec: 145.397
    

    INFO:tensorflow:global_step/sec: 145.397
    

    INFO:tensorflow:loss = 0.7473666, step = 2901 (0.688 sec)
    

    INFO:tensorflow:loss = 0.7473666, step = 2901 (0.688 sec)
    

    INFO:tensorflow:global_step/sec: 143.394
    

    INFO:tensorflow:global_step/sec: 143.394
    

    INFO:tensorflow:loss = 0.6989927, step = 3001 (0.698 sec)
    

    INFO:tensorflow:loss = 0.6989927, step = 3001 (0.698 sec)
    

    INFO:tensorflow:global_step/sec: 145.246
    

    INFO:tensorflow:global_step/sec: 145.246
    

    INFO:tensorflow:loss = 0.6838574, step = 3101 (0.688 sec)
    

    INFO:tensorflow:loss = 0.6838574, step = 3101 (0.688 sec)
    

    INFO:tensorflow:global_step/sec: 145.325
    

    INFO:tensorflow:global_step/sec: 145.325
    

    INFO:tensorflow:loss = 0.6576452, step = 3201 (0.688 sec)
    

    INFO:tensorflow:loss = 0.6576452, step = 3201 (0.688 sec)
    

    INFO:tensorflow:global_step/sec: 146.007
    

    INFO:tensorflow:global_step/sec: 146.007
    

    INFO:tensorflow:loss = 0.6723913, step = 3301 (0.685 sec)
    

    INFO:tensorflow:loss = 0.6723913, step = 3301 (0.685 sec)
    

    INFO:tensorflow:global_step/sec: 145.738
    

    INFO:tensorflow:global_step/sec: 145.738
    

    INFO:tensorflow:loss = 0.7514761, step = 3401 (0.686 sec)
    

    INFO:tensorflow:loss = 0.7514761, step = 3401 (0.686 sec)
    

    INFO:tensorflow:global_step/sec: 146.643
    

    INFO:tensorflow:global_step/sec: 146.643
    

    INFO:tensorflow:loss = 0.6445804, step = 3501 (0.682 sec)
    

    INFO:tensorflow:loss = 0.6445804, step = 3501 (0.682 sec)
    

    INFO:tensorflow:global_step/sec: 144.232
    

    INFO:tensorflow:global_step/sec: 144.232
    

    INFO:tensorflow:loss = 0.7299632, step = 3601 (0.693 sec)
    

    INFO:tensorflow:loss = 0.7299632, step = 3601 (0.693 sec)
    

    INFO:tensorflow:global_step/sec: 147.304
    

    INFO:tensorflow:global_step/sec: 147.304
    

    INFO:tensorflow:loss = 0.74484783, step = 3701 (0.679 sec)
    

    INFO:tensorflow:loss = 0.74484783, step = 3701 (0.679 sec)
    

    INFO:tensorflow:global_step/sec: 146.697
    

    INFO:tensorflow:global_step/sec: 146.697
    

    INFO:tensorflow:loss = 0.6711323, step = 3801 (0.682 sec)
    

    INFO:tensorflow:loss = 0.6711323, step = 3801 (0.682 sec)
    

    INFO:tensorflow:global_step/sec: 144.101
    

    INFO:tensorflow:global_step/sec: 144.101
    

    INFO:tensorflow:loss = 0.74910206, step = 3901 (0.694 sec)
    

    INFO:tensorflow:loss = 0.74910206, step = 3901 (0.694 sec)
    

    INFO:tensorflow:global_step/sec: 145.606
    

    INFO:tensorflow:global_step/sec: 145.606
    

    INFO:tensorflow:loss = 0.65817887, step = 4001 (0.687 sec)
    

    INFO:tensorflow:loss = 0.65817887, step = 4001 (0.687 sec)
    

    INFO:tensorflow:global_step/sec: 145.37
    

    INFO:tensorflow:global_step/sec: 145.37
    

    INFO:tensorflow:loss = 0.72360075, step = 4101 (0.688 sec)
    

    INFO:tensorflow:loss = 0.72360075, step = 4101 (0.688 sec)
    

    INFO:tensorflow:global_step/sec: 145.387
    

    INFO:tensorflow:global_step/sec: 145.387
    

    INFO:tensorflow:loss = 0.7745108, step = 4201 (0.688 sec)
    

    INFO:tensorflow:loss = 0.7745108, step = 4201 (0.688 sec)
    

    INFO:tensorflow:global_step/sec: 145.796
    

    INFO:tensorflow:global_step/sec: 145.796
    

    INFO:tensorflow:loss = 0.7876081, step = 4301 (0.686 sec)
    

    INFO:tensorflow:loss = 0.7876081, step = 4301 (0.686 sec)
    

    INFO:tensorflow:global_step/sec: 136.191
    

    INFO:tensorflow:global_step/sec: 136.191
    

    INFO:tensorflow:loss = 0.7237567, step = 4401 (0.735 sec)
    

    INFO:tensorflow:loss = 0.7237567, step = 4401 (0.735 sec)
    

    INFO:tensorflow:global_step/sec: 129.657
    

    INFO:tensorflow:global_step/sec: 129.657
    

    INFO:tensorflow:loss = 0.70355237, step = 4501 (0.771 sec)
    

    INFO:tensorflow:loss = 0.70355237, step = 4501 (0.771 sec)
    

    INFO:tensorflow:global_step/sec: 138.309
    

    INFO:tensorflow:global_step/sec: 138.309
    

    INFO:tensorflow:loss = 0.7436478, step = 4601 (0.723 sec)
    

    INFO:tensorflow:loss = 0.7436478, step = 4601 (0.723 sec)
    

    INFO:tensorflow:global_step/sec: 137.243
    

    INFO:tensorflow:global_step/sec: 137.243
    

    INFO:tensorflow:loss = 0.7039898, step = 4701 (0.728 sec)
    

    INFO:tensorflow:loss = 0.7039898, step = 4701 (0.728 sec)
    

    INFO:tensorflow:global_step/sec: 144.234
    

    INFO:tensorflow:global_step/sec: 144.234
    

    INFO:tensorflow:loss = 0.8143608, step = 4801 (0.693 sec)
    

    INFO:tensorflow:loss = 0.8143608, step = 4801 (0.693 sec)
    

    INFO:tensorflow:global_step/sec: 146.477
    

    INFO:tensorflow:global_step/sec: 146.477
    

    INFO:tensorflow:loss = 0.7548163, step = 4901 (0.683 sec)
    

    INFO:tensorflow:loss = 0.7548163, step = 4901 (0.683 sec)
    

    INFO:tensorflow:global_step/sec: 146.465
    

    INFO:tensorflow:global_step/sec: 146.465
    

    INFO:tensorflow:loss = 0.7269412, step = 5001 (0.683 sec)
    

    INFO:tensorflow:loss = 0.7269412, step = 5001 (0.683 sec)
    

    INFO:tensorflow:global_step/sec: 139.662
    

    INFO:tensorflow:global_step/sec: 139.662
    

    INFO:tensorflow:loss = 0.6949016, step = 5101 (0.716 sec)
    

    INFO:tensorflow:loss = 0.6949016, step = 5101 (0.716 sec)
    

    INFO:tensorflow:global_step/sec: 138.997
    

    INFO:tensorflow:global_step/sec: 138.997
    

    INFO:tensorflow:loss = 0.6816639, step = 5201 (0.720 sec)
    

    INFO:tensorflow:loss = 0.6816639, step = 5201 (0.720 sec)
    

    INFO:tensorflow:global_step/sec: 127.36
    

    INFO:tensorflow:global_step/sec: 127.36
    

    INFO:tensorflow:loss = 0.71083957, step = 5301 (0.785 sec)
    

    INFO:tensorflow:loss = 0.71083957, step = 5301 (0.785 sec)
    

    INFO:tensorflow:global_step/sec: 136.297
    

    INFO:tensorflow:global_step/sec: 136.297
    

    INFO:tensorflow:loss = 0.70206356, step = 5401 (0.734 sec)
    

    INFO:tensorflow:loss = 0.70206356, step = 5401 (0.734 sec)
    

    INFO:tensorflow:global_step/sec: 138.731
    

    INFO:tensorflow:global_step/sec: 138.731
    

    INFO:tensorflow:loss = 0.74185395, step = 5501 (0.721 sec)
    

    INFO:tensorflow:loss = 0.74185395, step = 5501 (0.721 sec)
    

    INFO:tensorflow:global_step/sec: 144.572
    

    INFO:tensorflow:global_step/sec: 144.572
    

    INFO:tensorflow:loss = 0.695399, step = 5601 (0.692 sec)
    

    INFO:tensorflow:loss = 0.695399, step = 5601 (0.692 sec)
    

    INFO:tensorflow:global_step/sec: 140.951
    

    INFO:tensorflow:global_step/sec: 140.951
    

    INFO:tensorflow:loss = 0.6712694, step = 5701 (0.709 sec)
    

    INFO:tensorflow:loss = 0.6712694, step = 5701 (0.709 sec)
    

    INFO:tensorflow:global_step/sec: 140.544
    

    INFO:tensorflow:global_step/sec: 140.544
    

    INFO:tensorflow:loss = 0.8122556, step = 5801 (0.711 sec)
    

    INFO:tensorflow:loss = 0.8122556, step = 5801 (0.711 sec)
    

    INFO:tensorflow:global_step/sec: 141.835
    

    INFO:tensorflow:global_step/sec: 141.835
    

    INFO:tensorflow:loss = 0.6804515, step = 5901 (0.705 sec)
    

    INFO:tensorflow:loss = 0.6804515, step = 5901 (0.705 sec)
    

    INFO:tensorflow:Saving checkpoints for 6000 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt.
    

    INFO:tensorflow:Saving checkpoints for 6000 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt.
    

    INFO:tensorflow:Loss for final step: 0.68594474.
    

    INFO:tensorflow:Loss for final step: 0.68594474.
    




    <tensorflow.contrib.timeseries.python.timeseries.estimators.ARRegressor at 0x7fbf01701890>




```python
#evaluation

evaluation_input_fn = tf.contrib.timeseries.WholeDatasetInputFn(reader)
evaluation = ar.evaluate(input_fn=evaluation_input_fn, steps=1000)
```

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02c6ba10>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02c6ba10>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02c6ba10>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02c6ba10>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02c6ba10>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf02c6ba10>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Starting evaluation at 2020-12-01T22:08:02Z
    

    INFO:tensorflow:Starting evaluation at 2020-12-01T22:08:02Z
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt-6000
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt-6000
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Evaluation [100/1000]
    

    INFO:tensorflow:Evaluation [100/1000]
    

    INFO:tensorflow:Evaluation [200/1000]
    

    INFO:tensorflow:Evaluation [200/1000]
    

    INFO:tensorflow:Evaluation [300/1000]
    

    INFO:tensorflow:Evaluation [300/1000]
    

    INFO:tensorflow:Evaluation [400/1000]
    

    INFO:tensorflow:Evaluation [400/1000]
    

    INFO:tensorflow:Evaluation [500/1000]
    

    INFO:tensorflow:Evaluation [500/1000]
    

    INFO:tensorflow:Evaluation [600/1000]
    

    INFO:tensorflow:Evaluation [600/1000]
    

    INFO:tensorflow:Evaluation [700/1000]
    

    INFO:tensorflow:Evaluation [700/1000]
    

    INFO:tensorflow:Evaluation [800/1000]
    

    INFO:tensorflow:Evaluation [800/1000]
    

    INFO:tensorflow:Evaluation [900/1000]
    

    INFO:tensorflow:Evaluation [900/1000]
    

    INFO:tensorflow:Evaluation [1000/1000]
    

    INFO:tensorflow:Evaluation [1000/1000]
    

    INFO:tensorflow:Finished evaluation at 2020-12-01-22:08:06
    

    INFO:tensorflow:Finished evaluation at 2020-12-01-22:08:06
    

    INFO:tensorflow:Saving dict for global step 6000: average_loss = 1.6794804, covariance = [[[2.03796554e+00]
      [2.40742898e+00]
      [5.75269818e-01]
      [1.55298877e+00]
      [2.79150367e+00]
      [6.71850860e-01]
      [4.56455278e+00]
      [1.51915073e+00]
      [3.90309811e-01]
      [2.56905764e-01]
      [9.14510059e+00]
      [2.79724503e+01]
      [2.30527782e+01]
      [1.18646979e+00]
      [7.54935026e-01]
      [8.00817490e-01]
      [8.47767234e-01]
      [1.63070595e+00]
      [5.16378701e-01]
      [2.71619707e-01]
      [6.44626915e-01]
      [3.46324730e+00]
      [6.85278320e+01]
      [3.10721893e+01]
      [2.37721615e+01]
      [1.43572741e+01]
      [2.20001183e+01]
      [9.66532040e+00]
      [2.12271900e+01]
      [4.84945583e+00]
      [1.67086351e+00]
      [3.14499283e+00]
      [3.84255886e+00]
      [1.13961306e+01]
      [1.22727280e+01]
      [1.81096191e+01]
      [2.08881874e+01]
      [2.60300159e+01]
      [1.61351128e+01]
      [1.56450214e+01]
      [8.82918262e+00]
      [3.77232094e+01]
      [2.44595222e+01]
      [5.21056709e+01]
      [2.99469070e+01]
      [2.63249283e+01]
      [1.45082264e+01]
      [1.43712358e+01]
      [1.43347235e+01]
      [2.88428307e+01]
      [2.44106317e+00]
      [1.31744518e+01]
      [2.32890244e+01]
      [4.52122955e+01]
      [2.96695461e+01]
      [2.71153736e+01]
      [1.84151440e+01]
      [1.94374027e+01]
      [1.72532902e+01]
      [2.60401382e+01]
      [2.10387254e+00]
      [5.02480745e+00]
      [3.10977054e+00]
      [1.09240179e+01]
      [1.21060505e+01]
      [2.83248768e+01]
      [2.90289993e+01]
      [1.88717079e+01]
      [4.74463158e+01]
      [3.23565559e+01]
      [1.82425785e+01]
      [6.29359207e+01]
      [9.43604660e+01]
      [5.34011688e+01]
      [5.18615837e+01]
      [5.48832932e+01]
      [2.48753567e+01]
      [2.09306831e+01]
      [1.19934473e+01]
      [1.17569056e+01]
      [3.21539021e+00]
      [4.27631283e+00]
      [5.63816690e+00]
      [3.47432213e+01]
      [2.11923656e+01]
      [2.76322784e+01]
      [2.77449150e+01]
      [3.48298988e+01]
      [6.31209793e+01]
      [5.31884232e+01]
      [3.78994846e+00]
      [7.33717489e+00]
      [1.33207245e+01]
      [2.21689987e+01]
      [2.47138882e+01]
      [3.00180244e+01]
      [3.75352936e+01]
      [2.76527195e+01]
      [1.79155045e+01]
      [2.84131203e+01]
      [5.69707060e+00]
      [2.23168964e+01]
      [1.62749405e+01]
      [2.54342003e+01]
      [4.55033684e+01]
      [3.27767715e+01]
      [2.33289032e+01]
      [1.81766663e+01]
      [2.30108070e+01]
      [2.36892414e+01]
      [2.51762152e+00]
      [5.18014288e+00]
      [1.02490339e+01]
      [2.41312962e+01]
      [3.34922371e+01]
      [2.24459896e+01]
      [2.64976444e+01]
      [2.28144722e+01]
      [2.78083935e+01]
      [2.08125687e+01]
      [1.19516504e+00]
      [1.88196707e+00]
      [5.73056650e+00]
      [1.30227423e+01]
      [1.86462154e+01]
      [2.54271603e+01]
      [3.20299683e+01]
      [3.07559147e+01]
      [1.98328609e+01]
      [1.53299503e+01]
      [2.33337522e+00]
      [5.77727556e+00]
      [1.20562325e+01]
      [2.81190968e+01]
      [2.47585239e+01]
      [3.58284073e+01]
      [2.71524811e+01]
      [2.50436726e+01]
      [3.28965759e+01]
      [2.82709751e+01]
      [3.13996553e+00]
      [8.88617706e+00]
      [1.18233128e+01]
      [1.69531441e+01]
      [5.69527550e+01]
      [5.00122375e+01]
      [4.37044525e+01]
      [2.37748947e+01]
      [3.10477753e+01]
      [2.91763077e+01]
      [4.41963623e+03]
      [1.60157803e+04]
      [1.72808875e+03]
      [1.51413315e+02]
      [1.46238737e+01]
      [3.72040024e+01]
      [1.13993549e+01]
      [2.07291341e+00]
      [3.35882926e+00]
      [9.42058849e+00]
      [5.22468233e+00]
      [1.88732014e+01]
      [3.62804718e+01]
      [6.09552917e+02]
      [4.28033562e+01]
      [6.09517813e+00]
      [9.15066242e+00]
      [6.80054140e+00]
      [8.41089439e+00]
      [3.77961006e+01]
      [1.29175961e+00]
      [3.23772043e-01]
      [7.41887763e-02]
      [4.15064430e+01]
      [1.18873310e+01]
      [2.29890518e+01]
      [2.91524792e+00]
      [4.48400545e+00]
      [2.82309971e+01]
      [6.77991257e+01]
      [3.54104042e+00]
      [1.37343130e+01]
      [1.40815413e+00]
      [5.55230446e+01]
      [7.03373413e+01]
      [9.48707771e+00]
      [1.10152311e+01]
      [1.59897966e+01]
      [1.31040220e+01]
      [3.40808945e+01]
      [3.03018689e+00]
      [1.66515808e+01]
      [7.79190493e+00]
      [1.20779295e+01]
      [5.24133377e+01]
      [3.11253548e+01]
      [2.11699848e+01]
      [1.70362854e+01]
      [2.74947567e+01]
      [3.20991859e+01]
      [2.38519490e-01]
      [8.11406791e-01]
      [4.92707586e+00]
      [1.80503635e+01]
      [1.97386227e+01]
      [2.28682060e+01]
      [2.01156311e+01]
      [2.26479206e+01]
      [2.54121246e+01]
      [1.49505548e+01]
      [1.17108917e+01]
      [6.10806007e+01]
      [2.60051041e+01]
      [5.46433334e+01]
      [1.00272224e+02]
      [4.88961563e+01]
      [2.82088623e+01]
      [1.07712612e+01]
      [1.22533836e+01]
      [2.15484600e+01]
      [5.77840948e+00]
      [1.91626606e+01]
      [2.81093178e+01]
      [5.87198563e+01]
      [3.76328354e+01]
      [2.43919621e+01]
      [1.73820972e+01]
      [8.74448776e+00]
      [1.75960999e+01]
      [2.58962212e+01]
      [2.88633251e+00]
      [1.08538208e+01]
      [1.02102776e+01]
      [4.16868324e+01]
      [3.46146507e+01]
      [1.74209614e+01]
      [1.59576073e+01]
      [1.19430532e+01]
      [1.77629662e+01]
      [1.48539944e+01]
      [1.10702217e+00]
      [1.55661786e+00]
      [4.75197172e+00]
      [1.52947617e+01]
      [2.16241875e+01]
      [3.26547279e+01]
      [4.08451843e+01]
      [2.91338673e+01]
      [2.52682705e+01]
      [2.01180782e+01]]], global_step = 6000, loss = 1.6794804, mean = [[[ 3.98746133e+00]
      [ 4.84312582e+00]
      [ 3.98274064e+00]
      [ 4.00882435e+00]
      [ 7.69969845e+00]
      [ 9.34335041e+00]
      [ 1.02302542e+01]
      [ 1.10204411e+01]
      [ 1.11632023e+01]
      [ 1.12864361e+01]
      [ 1.33947773e+01]
      [ 1.33925085e+01]
      [ 1.07874804e+01]
      [ 1.26930752e+01]
      [ 1.39072523e+01]
      [ 2.32358646e+00]
      [ 1.62934351e+00]
      [ 1.74150801e+00]
      [ 2.13337183e+00]
      [ 2.24022007e+00]
      [ 2.22014570e+00]
      [ 1.90175581e+00]
      [ 2.87824249e+00]
      [ 2.41015482e+00]
      [ 3.37988615e+00]
      [ 2.06227160e+00]
      [ 3.73433399e+00]
      [ 4.72426891e+00]
      [ 4.67913580e+00]
      [ 6.65764093e+00]
      [ 6.17045116e+00]
      [ 6.49965906e+00]
      [ 7.17294407e+00]
      [ 5.17418957e+00]
      [ 5.82130194e+00]
      [ 5.55800629e+00]
      [ 6.68467665e+00]
      [ 5.82089663e+00]
      [ 5.62842989e+00]
      [ 5.13955545e+00]
      [ 1.64486742e+00]
      [ 3.49282455e+00]
      [ 2.64565516e+00]
      [ 1.86469698e+00]
      [ 2.83846235e+00]
      [ 1.79183197e+00]
      [ 3.30970049e+00]
      [ 3.72881198e+00]
      [ 3.06027436e+00]
      [ 3.69384456e+00]
      [ 4.29572010e+00]
      [ 4.60301113e+00]
      [ 6.87817764e+00]
      [ 3.21508884e+00]
      [ 2.86828566e+00]
      [ 3.60271525e+00]
      [ 5.33735037e+00]
      [ 3.80896354e+00]
      [ 4.43461132e+00]
      [ 4.51840925e+00]
      [ 7.94644356e-01]
      [ 1.03150654e+00]
      [ 1.76369715e+00]
      [ 2.96494532e+00]
      [ 5.09316111e+00]
      [ 2.69759274e+00]
      [ 3.96700978e+00]
      [ 5.08306742e+00]
      [ 4.41932964e+00]
      [ 5.64259720e+00]
      [ 7.28630638e+00]
      [ 8.62594891e+00]
      [ 8.26268291e+00]
      [ 4.90416431e+00]
      [ 3.42981243e+00]
      [ 4.45686436e+00]
      [ 3.75552344e+00]
      [ 5.54559803e+00]
      [ 4.18076992e+00]
      [ 5.94423342e+00]
      [ 1.06627178e+00]
      [ 1.34116173e+00]
      [ 2.07511234e+00]
      [ 2.84247160e+00]
      [ 3.31642652e+00]
      [ 3.30793190e+00]
      [ 4.41722345e+00]
      [ 4.05484772e+00]
      [ 3.27336216e+00]
      [ 3.74278307e+00]
      [ 7.33295488e+00]
      [ 7.25505877e+00]
      [ 7.31554842e+00]
      [ 6.71083069e+00]
      [ 5.42822313e+00]
      [ 5.45702839e+00]
      [ 5.91321945e+00]
      [ 4.92394352e+00]
      [ 4.71773529e+00]
      [ 3.44648337e+00]
      [ 7.72555304e+00]
      [ 7.35846090e+00]
      [ 5.97488165e+00]
      [ 3.81872153e+00]
      [ 2.94549561e+00]
      [ 2.56773901e+00]
      [ 2.33554697e+00]
      [ 3.14793324e+00]
      [ 3.27309155e+00]
      [ 3.08146501e+00]
      [ 2.38247395e+00]
      [ 1.89278889e+00]
      [ 1.23079491e+00]
      [ 3.17430210e+00]
      [ 3.46212697e+00]
      [ 3.52001977e+00]
      [ 4.15354443e+00]
      [ 4.92540550e+00]
      [ 4.37108231e+00]
      [ 4.49660587e+00]
      [ 3.98967004e+00]
      [ 4.41901875e+00]
      [ 4.60820293e+00]
      [ 6.31566763e+00]
      [ 6.23827791e+00]
      [ 4.72828007e+00]
      [ 5.13598061e+00]
      [ 4.85851097e+00]
      [ 4.57726526e+00]
      [ 5.07654572e+00]
      [ 3.28336930e+00]
      [ 3.80271864e+00]
      [ 3.76817489e+00]
      [ 4.31409359e+00]
      [ 3.95588350e+00]
      [ 3.16978383e+00]
      [ 3.65894556e+00]
      [ 3.59143567e+00]
      [ 3.26256871e+00]
      [ 3.23699832e+00]
      [ 5.30586243e+00]
      [ 4.63298512e+00]
      [ 5.87311745e+00]
      [ 4.11384201e+00]
      [ 3.27584362e+00]
      [ 3.34397078e+00]
      [ 3.43304777e+00]
      [ 4.05822325e+00]
      [ 3.94485211e+00]
      [ 5.76505327e+00]
      [ 3.57770844e+01]
      [ 3.34733810e+01]
      [ 2.79164543e+01]
      [ 1.02101841e+01]
      [ 1.04942226e+01]
      [ 6.25481081e+00]
      [ 5.79374647e+00]
      [ 3.20918894e+00]
      [ 4.25388813e-01]
      [ 2.62883663e-01]
      [ 1.13254328e+01]
      [ 7.22835255e+00]
      [ 1.34872704e+01]
      [-4.24432278e-01]
      [ 6.26748371e+00]
      [-1.53276348e+00]
      [ 7.14968586e+00]
      [ 7.16262102e+00]
      [-3.37362862e+00]
      [ 4.06887722e+00]
      [ 3.41177464e+00]
      [ 2.77738619e+00]
      [ 1.09817410e+01]
      [ 2.19560051e+00]
      [ 7.01595545e+00]
      [ 8.25491238e+00]
      [ 1.22771339e+01]
      [ 6.59073496e+00]
      [ 1.79848003e+00]
      [ 6.24984932e+00]
      [ 1.33865881e+00]
      [-1.60646439e-02]
      [ 5.86834240e+00]
      [ 6.16039276e-01]
      [ 5.47327900e+00]
      [ 2.86087990e+00]
      [ 6.15180826e+00]
      [ 6.56499147e+00]
      [ 3.64273310e+00]
      [ 5.04879475e+00]
      [ 1.13364220e+00]
      [ 1.57776308e+00]
      [ 3.38838124e+00]
      [ 2.66670275e+00]
      [ 4.18642426e+00]
      [ 3.12723064e+00]
      [ 3.50954366e+00]
      [ 4.28684807e+00]
      [ 5.46052647e+00]
      [ 7.68567228e+00]
      [ 2.04335403e+00]
      [ 2.72791672e+00]
      [ 3.40356874e+00]
      [ 5.35771275e+00]
      [ 4.72408104e+00]
      [ 3.97380257e+00]
      [ 5.80859661e+00]
      [ 6.05266237e+00]
      [ 6.21583128e+00]
      [ 4.17203903e+00]
      [ 4.25542545e+00]
      [ 5.59123707e+00]
      [ 4.93960094e+00]
      [ 2.95125294e+00]
      [ 3.07923174e+00]
      [ 7.91254997e-01]
      [ 2.74338627e+00]
      [ 3.94063473e+00]
      [ 3.62098980e+00]
      [ 5.28768110e+00]
      [ 8.18071747e+00]
      [ 6.94368505e+00]
      [ 7.70496559e+00]
      [ 4.42491817e+00]
      [ 3.39023495e+00]
      [ 3.13767600e+00]
      [ 4.10237598e+00]
      [ 3.65440536e+00]
      [ 4.09994507e+00]
      [ 4.25813198e+00]
      [ 3.97272706e+00]
      [ 2.73027897e+00]
      [ 3.66864038e+00]
      [ 3.74091530e+00]
      [ 4.00549126e+00]
      [ 3.20652342e+00]
      [ 4.05669212e+00]
      [ 4.84792805e+00]
      [ 5.90282631e+00]
      [ 5.65903950e+00]
      [ 1.58841896e+00]
      [ 1.97153616e+00]
      [ 2.68911314e+00]
      [ 5.55756044e+00]
      [ 5.80999851e+00]
      [ 5.61438227e+00]
      [ 6.08190680e+00]
      [ 5.34882021e+00]
      [ 5.66127586e+00]
      [ 5.93660545e+00]]], observed = [[[ 4.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 8.]
      [ 9.]
      [ 9.]
      [10.]
      [11.]
      [11.]
      [14.]
      [13.]
      [14.]
      [13.]
      [13.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 6.]
      [ 6.]
      [ 6.]
      [ 8.]
      [11.]
      [11.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 7.]
      [ 7.]
      [11.]
      [11.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 5.]
      [12.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 6.]
      [ 6.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 5.]
      [ 5.]
      [ 8.]
      [ 8.]
      [10.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 7.]
      [ 7.]
      [ 3.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 1.]
      [ 1.]
      [11.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 2.]
      [34.]
      [40.]
      [ 8.]
      [15.]
      [15.]
      [ 6.]
      [21.]
      [10.]
      [ 8.]
      [ 7.]
      [32.]
      [18.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 9.]
      [ 7.]
      [ 3.]
      [ 3.]
      [11.]
      [11.]
      [11.]
      [14.]
      [14.]
      [ 7.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [13.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [ 4.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 9.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 6.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]]], start_tuple = (array([[1503205200, 1503291600, 1503378000, 1503464400, 1503550800,
            1503637200, 1503723600, 1503810000, 1503896400, 1503982800,
            1504069200, 1504155600, 1505278800, 1505365200, 1505451600,
            1505538000, 1505624400, 1505710800, 1505797200, 1505883600,
            1505970000, 1506056400, 1506142800, 1506229200, 1506315600,
            1506402000, 1506488400, 1506574800, 1506661200, 1506747600]]), array([[[ 0.24315733],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [-0.11084344],
            [-0.2288437 ],
            [-0.34684396],
            [-0.4648442 ],
            [-0.4648442 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ]]], dtype=float32), array([], shape=(1, 30, 0), dtype=float32)), times = [[1494046800 1494133200 1494219600 1494306000 1494392400 1494478800
      1494565200 1496638800 1496725200 1496811600 1496898000 1496984400
      1497070800 1497157200 1497243600 1498885200 1498971600 1499058000
      1499144400 1499230800 1499317200 1499403600 1499490000 1499576400
      1499662800 1499749200 1499835600 1501563600 1501650000 1501736400
      1501822800 1501909200 1501995600 1502082000 1502168400 1502254800
      1502341200 1502427600 1502514000 1504242000 1504328400 1505192400
      1484287200 1484373600 1484460000 1484546400 1484632800 1484719200
      1484805600 1484892000 1484978400 1485064800 1506834000 1506920400
      1507006800 1507093200 1507179600 1507266000 1507352400 1507438800
      1507525200 1507611600 1507698000 1507784400 1507870800 1507957200
      1508043600 1508130000 1508216400 1508302800 1508389200 1508475600
      1508562000 1508648400 1508734800 1508821200 1508907600 1508994000
      1509080400 1509166800 1509253200 1509339600 1509512400 1509598800
      1509685200 1509771600 1509858000 1509948000 1510034400 1510120800
      1510207200 1510293600 1510380000 1510466400 1510552800 1510639200
      1510725600 1510812000 1510898400 1510984800 1511071200 1511157600
      1511244000 1511330400 1511416800 1511503200 1511589600 1511676000
      1511762400 1511848800 1511935200 1512021600 1512108000 1512194400
      1512280800 1512367200 1512453600 1512540000 1512626400 1512712800
      1512799200 1512885600 1512972000 1513058400 1513144800 1513231200
      1513317600 1513404000 1513490400 1513576800 1513663200 1513749600
      1513836000 1513922400 1486965600 1487052000 1487138400 1487224800
      1487311200 1487397600 1487484000 1487570400 1487656800 1487743200
      1487829600 1487916000 1488002400 1488088800 1488175200 1488261600
      1489381200 1489467600 1489554000 1489640400 1489726800 1489813200
      1489899600 1489986000 1492059600 1492146000 1492232400 1492318800
      1492405200 1492491600 1492578000 1492664400 1492750800 1492837200
      1494651600 1494738000 1494824400 1494910800 1494997200 1495083600
      1495170000 1495256400 1495342800 1495429200 1495515600 1495602000
      1495688400 1495774800 1495861200 1495947600 1497330000 1497416400
      1497502800 1497589200 1497675600 1497762000 1497848400 1497934800
      1498021200 1498107600 1498194000 1498280400 1498366800 1498453200
      1498539600 1498626000 1499922000 1500008400 1500094800 1500181200
      1500267600 1500354000 1500440400 1500526800 1500613200 1500699600
      1500786000 1500872400 1500958800 1502600400 1502686800 1502773200
      1502859600 1502946000 1503032400 1503118800 1503205200 1503291600
      1503378000 1503464400 1503550800 1503637200 1503723600 1503810000
      1503896400 1503982800 1504069200 1504155600 1505278800 1505365200
      1505451600 1505538000 1505624400 1505710800 1505797200 1505883600
      1505970000 1506056400 1506142800 1506229200 1506315600 1506402000
      1506488400 1506574800 1506661200 1506747600]]
    

    INFO:tensorflow:Saving dict for global step 6000: average_loss = 1.6794804, covariance = [[[2.03796554e+00]
      [2.40742898e+00]
      [5.75269818e-01]
      [1.55298877e+00]
      [2.79150367e+00]
      [6.71850860e-01]
      [4.56455278e+00]
      [1.51915073e+00]
      [3.90309811e-01]
      [2.56905764e-01]
      [9.14510059e+00]
      [2.79724503e+01]
      [2.30527782e+01]
      [1.18646979e+00]
      [7.54935026e-01]
      [8.00817490e-01]
      [8.47767234e-01]
      [1.63070595e+00]
      [5.16378701e-01]
      [2.71619707e-01]
      [6.44626915e-01]
      [3.46324730e+00]
      [6.85278320e+01]
      [3.10721893e+01]
      [2.37721615e+01]
      [1.43572741e+01]
      [2.20001183e+01]
      [9.66532040e+00]
      [2.12271900e+01]
      [4.84945583e+00]
      [1.67086351e+00]
      [3.14499283e+00]
      [3.84255886e+00]
      [1.13961306e+01]
      [1.22727280e+01]
      [1.81096191e+01]
      [2.08881874e+01]
      [2.60300159e+01]
      [1.61351128e+01]
      [1.56450214e+01]
      [8.82918262e+00]
      [3.77232094e+01]
      [2.44595222e+01]
      [5.21056709e+01]
      [2.99469070e+01]
      [2.63249283e+01]
      [1.45082264e+01]
      [1.43712358e+01]
      [1.43347235e+01]
      [2.88428307e+01]
      [2.44106317e+00]
      [1.31744518e+01]
      [2.32890244e+01]
      [4.52122955e+01]
      [2.96695461e+01]
      [2.71153736e+01]
      [1.84151440e+01]
      [1.94374027e+01]
      [1.72532902e+01]
      [2.60401382e+01]
      [2.10387254e+00]
      [5.02480745e+00]
      [3.10977054e+00]
      [1.09240179e+01]
      [1.21060505e+01]
      [2.83248768e+01]
      [2.90289993e+01]
      [1.88717079e+01]
      [4.74463158e+01]
      [3.23565559e+01]
      [1.82425785e+01]
      [6.29359207e+01]
      [9.43604660e+01]
      [5.34011688e+01]
      [5.18615837e+01]
      [5.48832932e+01]
      [2.48753567e+01]
      [2.09306831e+01]
      [1.19934473e+01]
      [1.17569056e+01]
      [3.21539021e+00]
      [4.27631283e+00]
      [5.63816690e+00]
      [3.47432213e+01]
      [2.11923656e+01]
      [2.76322784e+01]
      [2.77449150e+01]
      [3.48298988e+01]
      [6.31209793e+01]
      [5.31884232e+01]
      [3.78994846e+00]
      [7.33717489e+00]
      [1.33207245e+01]
      [2.21689987e+01]
      [2.47138882e+01]
      [3.00180244e+01]
      [3.75352936e+01]
      [2.76527195e+01]
      [1.79155045e+01]
      [2.84131203e+01]
      [5.69707060e+00]
      [2.23168964e+01]
      [1.62749405e+01]
      [2.54342003e+01]
      [4.55033684e+01]
      [3.27767715e+01]
      [2.33289032e+01]
      [1.81766663e+01]
      [2.30108070e+01]
      [2.36892414e+01]
      [2.51762152e+00]
      [5.18014288e+00]
      [1.02490339e+01]
      [2.41312962e+01]
      [3.34922371e+01]
      [2.24459896e+01]
      [2.64976444e+01]
      [2.28144722e+01]
      [2.78083935e+01]
      [2.08125687e+01]
      [1.19516504e+00]
      [1.88196707e+00]
      [5.73056650e+00]
      [1.30227423e+01]
      [1.86462154e+01]
      [2.54271603e+01]
      [3.20299683e+01]
      [3.07559147e+01]
      [1.98328609e+01]
      [1.53299503e+01]
      [2.33337522e+00]
      [5.77727556e+00]
      [1.20562325e+01]
      [2.81190968e+01]
      [2.47585239e+01]
      [3.58284073e+01]
      [2.71524811e+01]
      [2.50436726e+01]
      [3.28965759e+01]
      [2.82709751e+01]
      [3.13996553e+00]
      [8.88617706e+00]
      [1.18233128e+01]
      [1.69531441e+01]
      [5.69527550e+01]
      [5.00122375e+01]
      [4.37044525e+01]
      [2.37748947e+01]
      [3.10477753e+01]
      [2.91763077e+01]
      [4.41963623e+03]
      [1.60157803e+04]
      [1.72808875e+03]
      [1.51413315e+02]
      [1.46238737e+01]
      [3.72040024e+01]
      [1.13993549e+01]
      [2.07291341e+00]
      [3.35882926e+00]
      [9.42058849e+00]
      [5.22468233e+00]
      [1.88732014e+01]
      [3.62804718e+01]
      [6.09552917e+02]
      [4.28033562e+01]
      [6.09517813e+00]
      [9.15066242e+00]
      [6.80054140e+00]
      [8.41089439e+00]
      [3.77961006e+01]
      [1.29175961e+00]
      [3.23772043e-01]
      [7.41887763e-02]
      [4.15064430e+01]
      [1.18873310e+01]
      [2.29890518e+01]
      [2.91524792e+00]
      [4.48400545e+00]
      [2.82309971e+01]
      [6.77991257e+01]
      [3.54104042e+00]
      [1.37343130e+01]
      [1.40815413e+00]
      [5.55230446e+01]
      [7.03373413e+01]
      [9.48707771e+00]
      [1.10152311e+01]
      [1.59897966e+01]
      [1.31040220e+01]
      [3.40808945e+01]
      [3.03018689e+00]
      [1.66515808e+01]
      [7.79190493e+00]
      [1.20779295e+01]
      [5.24133377e+01]
      [3.11253548e+01]
      [2.11699848e+01]
      [1.70362854e+01]
      [2.74947567e+01]
      [3.20991859e+01]
      [2.38519490e-01]
      [8.11406791e-01]
      [4.92707586e+00]
      [1.80503635e+01]
      [1.97386227e+01]
      [2.28682060e+01]
      [2.01156311e+01]
      [2.26479206e+01]
      [2.54121246e+01]
      [1.49505548e+01]
      [1.17108917e+01]
      [6.10806007e+01]
      [2.60051041e+01]
      [5.46433334e+01]
      [1.00272224e+02]
      [4.88961563e+01]
      [2.82088623e+01]
      [1.07712612e+01]
      [1.22533836e+01]
      [2.15484600e+01]
      [5.77840948e+00]
      [1.91626606e+01]
      [2.81093178e+01]
      [5.87198563e+01]
      [3.76328354e+01]
      [2.43919621e+01]
      [1.73820972e+01]
      [8.74448776e+00]
      [1.75960999e+01]
      [2.58962212e+01]
      [2.88633251e+00]
      [1.08538208e+01]
      [1.02102776e+01]
      [4.16868324e+01]
      [3.46146507e+01]
      [1.74209614e+01]
      [1.59576073e+01]
      [1.19430532e+01]
      [1.77629662e+01]
      [1.48539944e+01]
      [1.10702217e+00]
      [1.55661786e+00]
      [4.75197172e+00]
      [1.52947617e+01]
      [2.16241875e+01]
      [3.26547279e+01]
      [4.08451843e+01]
      [2.91338673e+01]
      [2.52682705e+01]
      [2.01180782e+01]]], global_step = 6000, loss = 1.6794804, mean = [[[ 3.98746133e+00]
      [ 4.84312582e+00]
      [ 3.98274064e+00]
      [ 4.00882435e+00]
      [ 7.69969845e+00]
      [ 9.34335041e+00]
      [ 1.02302542e+01]
      [ 1.10204411e+01]
      [ 1.11632023e+01]
      [ 1.12864361e+01]
      [ 1.33947773e+01]
      [ 1.33925085e+01]
      [ 1.07874804e+01]
      [ 1.26930752e+01]
      [ 1.39072523e+01]
      [ 2.32358646e+00]
      [ 1.62934351e+00]
      [ 1.74150801e+00]
      [ 2.13337183e+00]
      [ 2.24022007e+00]
      [ 2.22014570e+00]
      [ 1.90175581e+00]
      [ 2.87824249e+00]
      [ 2.41015482e+00]
      [ 3.37988615e+00]
      [ 2.06227160e+00]
      [ 3.73433399e+00]
      [ 4.72426891e+00]
      [ 4.67913580e+00]
      [ 6.65764093e+00]
      [ 6.17045116e+00]
      [ 6.49965906e+00]
      [ 7.17294407e+00]
      [ 5.17418957e+00]
      [ 5.82130194e+00]
      [ 5.55800629e+00]
      [ 6.68467665e+00]
      [ 5.82089663e+00]
      [ 5.62842989e+00]
      [ 5.13955545e+00]
      [ 1.64486742e+00]
      [ 3.49282455e+00]
      [ 2.64565516e+00]
      [ 1.86469698e+00]
      [ 2.83846235e+00]
      [ 1.79183197e+00]
      [ 3.30970049e+00]
      [ 3.72881198e+00]
      [ 3.06027436e+00]
      [ 3.69384456e+00]
      [ 4.29572010e+00]
      [ 4.60301113e+00]
      [ 6.87817764e+00]
      [ 3.21508884e+00]
      [ 2.86828566e+00]
      [ 3.60271525e+00]
      [ 5.33735037e+00]
      [ 3.80896354e+00]
      [ 4.43461132e+00]
      [ 4.51840925e+00]
      [ 7.94644356e-01]
      [ 1.03150654e+00]
      [ 1.76369715e+00]
      [ 2.96494532e+00]
      [ 5.09316111e+00]
      [ 2.69759274e+00]
      [ 3.96700978e+00]
      [ 5.08306742e+00]
      [ 4.41932964e+00]
      [ 5.64259720e+00]
      [ 7.28630638e+00]
      [ 8.62594891e+00]
      [ 8.26268291e+00]
      [ 4.90416431e+00]
      [ 3.42981243e+00]
      [ 4.45686436e+00]
      [ 3.75552344e+00]
      [ 5.54559803e+00]
      [ 4.18076992e+00]
      [ 5.94423342e+00]
      [ 1.06627178e+00]
      [ 1.34116173e+00]
      [ 2.07511234e+00]
      [ 2.84247160e+00]
      [ 3.31642652e+00]
      [ 3.30793190e+00]
      [ 4.41722345e+00]
      [ 4.05484772e+00]
      [ 3.27336216e+00]
      [ 3.74278307e+00]
      [ 7.33295488e+00]
      [ 7.25505877e+00]
      [ 7.31554842e+00]
      [ 6.71083069e+00]
      [ 5.42822313e+00]
      [ 5.45702839e+00]
      [ 5.91321945e+00]
      [ 4.92394352e+00]
      [ 4.71773529e+00]
      [ 3.44648337e+00]
      [ 7.72555304e+00]
      [ 7.35846090e+00]
      [ 5.97488165e+00]
      [ 3.81872153e+00]
      [ 2.94549561e+00]
      [ 2.56773901e+00]
      [ 2.33554697e+00]
      [ 3.14793324e+00]
      [ 3.27309155e+00]
      [ 3.08146501e+00]
      [ 2.38247395e+00]
      [ 1.89278889e+00]
      [ 1.23079491e+00]
      [ 3.17430210e+00]
      [ 3.46212697e+00]
      [ 3.52001977e+00]
      [ 4.15354443e+00]
      [ 4.92540550e+00]
      [ 4.37108231e+00]
      [ 4.49660587e+00]
      [ 3.98967004e+00]
      [ 4.41901875e+00]
      [ 4.60820293e+00]
      [ 6.31566763e+00]
      [ 6.23827791e+00]
      [ 4.72828007e+00]
      [ 5.13598061e+00]
      [ 4.85851097e+00]
      [ 4.57726526e+00]
      [ 5.07654572e+00]
      [ 3.28336930e+00]
      [ 3.80271864e+00]
      [ 3.76817489e+00]
      [ 4.31409359e+00]
      [ 3.95588350e+00]
      [ 3.16978383e+00]
      [ 3.65894556e+00]
      [ 3.59143567e+00]
      [ 3.26256871e+00]
      [ 3.23699832e+00]
      [ 5.30586243e+00]
      [ 4.63298512e+00]
      [ 5.87311745e+00]
      [ 4.11384201e+00]
      [ 3.27584362e+00]
      [ 3.34397078e+00]
      [ 3.43304777e+00]
      [ 4.05822325e+00]
      [ 3.94485211e+00]
      [ 5.76505327e+00]
      [ 3.57770844e+01]
      [ 3.34733810e+01]
      [ 2.79164543e+01]
      [ 1.02101841e+01]
      [ 1.04942226e+01]
      [ 6.25481081e+00]
      [ 5.79374647e+00]
      [ 3.20918894e+00]
      [ 4.25388813e-01]
      [ 2.62883663e-01]
      [ 1.13254328e+01]
      [ 7.22835255e+00]
      [ 1.34872704e+01]
      [-4.24432278e-01]
      [ 6.26748371e+00]
      [-1.53276348e+00]
      [ 7.14968586e+00]
      [ 7.16262102e+00]
      [-3.37362862e+00]
      [ 4.06887722e+00]
      [ 3.41177464e+00]
      [ 2.77738619e+00]
      [ 1.09817410e+01]
      [ 2.19560051e+00]
      [ 7.01595545e+00]
      [ 8.25491238e+00]
      [ 1.22771339e+01]
      [ 6.59073496e+00]
      [ 1.79848003e+00]
      [ 6.24984932e+00]
      [ 1.33865881e+00]
      [-1.60646439e-02]
      [ 5.86834240e+00]
      [ 6.16039276e-01]
      [ 5.47327900e+00]
      [ 2.86087990e+00]
      [ 6.15180826e+00]
      [ 6.56499147e+00]
      [ 3.64273310e+00]
      [ 5.04879475e+00]
      [ 1.13364220e+00]
      [ 1.57776308e+00]
      [ 3.38838124e+00]
      [ 2.66670275e+00]
      [ 4.18642426e+00]
      [ 3.12723064e+00]
      [ 3.50954366e+00]
      [ 4.28684807e+00]
      [ 5.46052647e+00]
      [ 7.68567228e+00]
      [ 2.04335403e+00]
      [ 2.72791672e+00]
      [ 3.40356874e+00]
      [ 5.35771275e+00]
      [ 4.72408104e+00]
      [ 3.97380257e+00]
      [ 5.80859661e+00]
      [ 6.05266237e+00]
      [ 6.21583128e+00]
      [ 4.17203903e+00]
      [ 4.25542545e+00]
      [ 5.59123707e+00]
      [ 4.93960094e+00]
      [ 2.95125294e+00]
      [ 3.07923174e+00]
      [ 7.91254997e-01]
      [ 2.74338627e+00]
      [ 3.94063473e+00]
      [ 3.62098980e+00]
      [ 5.28768110e+00]
      [ 8.18071747e+00]
      [ 6.94368505e+00]
      [ 7.70496559e+00]
      [ 4.42491817e+00]
      [ 3.39023495e+00]
      [ 3.13767600e+00]
      [ 4.10237598e+00]
      [ 3.65440536e+00]
      [ 4.09994507e+00]
      [ 4.25813198e+00]
      [ 3.97272706e+00]
      [ 2.73027897e+00]
      [ 3.66864038e+00]
      [ 3.74091530e+00]
      [ 4.00549126e+00]
      [ 3.20652342e+00]
      [ 4.05669212e+00]
      [ 4.84792805e+00]
      [ 5.90282631e+00]
      [ 5.65903950e+00]
      [ 1.58841896e+00]
      [ 1.97153616e+00]
      [ 2.68911314e+00]
      [ 5.55756044e+00]
      [ 5.80999851e+00]
      [ 5.61438227e+00]
      [ 6.08190680e+00]
      [ 5.34882021e+00]
      [ 5.66127586e+00]
      [ 5.93660545e+00]]], observed = [[[ 4.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 8.]
      [ 9.]
      [ 9.]
      [10.]
      [11.]
      [11.]
      [14.]
      [13.]
      [14.]
      [13.]
      [13.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 6.]
      [ 6.]
      [ 6.]
      [ 8.]
      [11.]
      [11.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 7.]
      [ 7.]
      [11.]
      [11.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 5.]
      [12.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 6.]
      [ 6.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 5.]
      [ 5.]
      [ 8.]
      [ 8.]
      [10.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 7.]
      [ 7.]
      [ 3.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 1.]
      [ 1.]
      [11.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 2.]
      [34.]
      [40.]
      [ 8.]
      [15.]
      [15.]
      [ 6.]
      [21.]
      [10.]
      [ 8.]
      [ 7.]
      [32.]
      [18.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 9.]
      [ 7.]
      [ 3.]
      [ 3.]
      [11.]
      [11.]
      [11.]
      [14.]
      [14.]
      [ 7.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [13.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [ 4.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 9.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 6.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]]], start_tuple = (array([[1503205200, 1503291600, 1503378000, 1503464400, 1503550800,
            1503637200, 1503723600, 1503810000, 1503896400, 1503982800,
            1504069200, 1504155600, 1505278800, 1505365200, 1505451600,
            1505538000, 1505624400, 1505710800, 1505797200, 1505883600,
            1505970000, 1506056400, 1506142800, 1506229200, 1506315600,
            1506402000, 1506488400, 1506574800, 1506661200, 1506747600]]), array([[[ 0.24315733],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [ 0.12515707],
            [-0.11084344],
            [-0.2288437 ],
            [-0.34684396],
            [-0.4648442 ],
            [-0.4648442 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ],
            [-0.7008447 ]]], dtype=float32), array([], shape=(1, 30, 0), dtype=float32)), times = [[1494046800 1494133200 1494219600 1494306000 1494392400 1494478800
      1494565200 1496638800 1496725200 1496811600 1496898000 1496984400
      1497070800 1497157200 1497243600 1498885200 1498971600 1499058000
      1499144400 1499230800 1499317200 1499403600 1499490000 1499576400
      1499662800 1499749200 1499835600 1501563600 1501650000 1501736400
      1501822800 1501909200 1501995600 1502082000 1502168400 1502254800
      1502341200 1502427600 1502514000 1504242000 1504328400 1505192400
      1484287200 1484373600 1484460000 1484546400 1484632800 1484719200
      1484805600 1484892000 1484978400 1485064800 1506834000 1506920400
      1507006800 1507093200 1507179600 1507266000 1507352400 1507438800
      1507525200 1507611600 1507698000 1507784400 1507870800 1507957200
      1508043600 1508130000 1508216400 1508302800 1508389200 1508475600
      1508562000 1508648400 1508734800 1508821200 1508907600 1508994000
      1509080400 1509166800 1509253200 1509339600 1509512400 1509598800
      1509685200 1509771600 1509858000 1509948000 1510034400 1510120800
      1510207200 1510293600 1510380000 1510466400 1510552800 1510639200
      1510725600 1510812000 1510898400 1510984800 1511071200 1511157600
      1511244000 1511330400 1511416800 1511503200 1511589600 1511676000
      1511762400 1511848800 1511935200 1512021600 1512108000 1512194400
      1512280800 1512367200 1512453600 1512540000 1512626400 1512712800
      1512799200 1512885600 1512972000 1513058400 1513144800 1513231200
      1513317600 1513404000 1513490400 1513576800 1513663200 1513749600
      1513836000 1513922400 1486965600 1487052000 1487138400 1487224800
      1487311200 1487397600 1487484000 1487570400 1487656800 1487743200
      1487829600 1487916000 1488002400 1488088800 1488175200 1488261600
      1489381200 1489467600 1489554000 1489640400 1489726800 1489813200
      1489899600 1489986000 1492059600 1492146000 1492232400 1492318800
      1492405200 1492491600 1492578000 1492664400 1492750800 1492837200
      1494651600 1494738000 1494824400 1494910800 1494997200 1495083600
      1495170000 1495256400 1495342800 1495429200 1495515600 1495602000
      1495688400 1495774800 1495861200 1495947600 1497330000 1497416400
      1497502800 1497589200 1497675600 1497762000 1497848400 1497934800
      1498021200 1498107600 1498194000 1498280400 1498366800 1498453200
      1498539600 1498626000 1499922000 1500008400 1500094800 1500181200
      1500267600 1500354000 1500440400 1500526800 1500613200 1500699600
      1500786000 1500872400 1500958800 1502600400 1502686800 1502773200
      1502859600 1502946000 1503032400 1503118800 1503205200 1503291600
      1503378000 1503464400 1503550800 1503637200 1503723600 1503810000
      1503896400 1503982800 1504069200 1504155600 1505278800 1505365200
      1505451600 1505538000 1505624400 1505710800 1505797200 1505883600
      1505970000 1506056400 1506142800 1506229200 1506315600 1506402000
      1506488400 1506574800 1506661200 1506747600]]
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    WARNING:tensorflow:Skipping summary for start_tuple, must be a float, np.float32, np.int64, np.int32 or int or np.ndarray or a serialized string of Summary.
    

    WARNING:tensorflow:Skipping summary for start_tuple, must be a float, np.float32, np.int64, np.int32 or int or np.ndarray or a serialized string of Summary.
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Saving 'checkpoint_path' summary for global step 6000: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt-6000
    

    INFO:tensorflow:Saving 'checkpoint_path' summary for global step 6000: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt-6000
    


```python
#prediction
(predictions,) = tuple(ar.predict(
        input_fn=tf.contrib.timeseries.predict_continuation_input_fn(
            evaluation, steps=365)))
```

    WARNING:tensorflow:Input graph does not use tf.data.Dataset or contain a QueueRunner. That means predict yields forever. This is probably a mistake.
    

    WARNING:tensorflow:Input graph does not use tf.data.Dataset or contain a QueueRunner. That means predict yields forever. This is probably a mistake.
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf0246f950>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf0246f950>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf0246f950>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf0246f950>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf0246f950>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf0246f950>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt-6000
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpugbt6rlz/model.ckpt-6000
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    


```python
#plot origin and evaluation 
plt.figure(figsize=(30, 5))
plt.plot(data['times'].reshape(-1), data['values'].reshape(-1), label='origin')
plt.plot(evaluation['times'].reshape(-1), evaluation['mean'].reshape(-1), label='evaluation')
plt.xlabel('time_step')
plt.ylabel('values')
plt.legend()
plt.show()
```


![png](output_30_0.png)



```python
#plot prediction
plt.figure(figsize=(30, 5))
plt.plot(predictions['times'].reshape(-1), predictions['mean'].reshape(-1), label='prediction')
plt.xlabel('time_step')
plt.ylabel('values')
plt.legend()
plt.show()
```


![png](output_31_0.png)



```python
# 1. The day of the weeek maximum number of issues created : TFTS
from datetime import date
#import calender
def most_num_of_issues_created(dataframe):
    data = (dataframe.groupby(['created_at']).count().reset_index()).sort_values('issue_number', ascending=False).head(1).iloc[0]['created_at']
    return data

max_number_issues_created = most_num_of_issues_created(issuesdf)

def convert(param):
    ans = datetime.date(pd.to_datetime(param))
    return ans.strftime("%A")

print("Day of week with max num of created_issues = ", max_number_issues_created, convert(max_number_issues_created))
```

    Day of week with max num of created_issues =  03-06-2017 Monday
    


```python
# 2. The day of the week maximum number of issues closed : TFTS

from datetime import date
#import calender
def most_num_of_issues_closed(dataframe):
    data = (dataframe.groupby(['closed_at']).count().reset_index()).sort_values('issue_number', ascending=False).head(1).iloc[0]['closed_at']
    return data

max_issues_closed = most_num_of_issues_closed(issuesdf)

def convert(param):
    ans = datetime.date(pd.to_datetime(param))
    return ans.strftime("%A")

print("Day of week with max num of closed_issues = ",max_issues_closed,convert(max_issues_closed))
```

    Day of week with max num of closed_issues =  03-10-2017 Friday
    


```python
#3. the month of the year that has maximum number of issues closed : TFTS

# Adding new column closed_month_year to new dataframes
issuesdf['closed_month_year'] = pd.to_datetime(issuesdf['closed_at']).dt.to_period('M')

max_no_issues_closed = issuesdf.groupby('closed_month_year').count()['issue_number'].idxmax(axis=0, skipna = True)

print("The month of the year that has maximum number of issues closed :",max_no_issues_closed.strftime('%B %F'))
```

    The month of the year that has maximum number of issues closed : March 2017
    


```python
#4. Plot the created issues forecast: TFTS

import tensorflow as tf
import importlib
import dateparser
import time

def date_conversion(date_str):
    a = dateparser.parse(date_str)
    t1 = a.timetuple()
    return int(time.mktime(t1))

def ar_train_and_predict(csv_file_name):
    ar = tf.contrib.timeseries.ARRegressor(
        periodicities=200, input_window_size=2, output_window_size=2,
        num_features=1,
    # Use the (default) normal likelihood loss to adaptively fit the
    # variance. SQUARED_LOSS overestimates variance when there are trends in
    # the series.
        loss=tf.contrib.timeseries.ARModel.NORMAL_LIKELIHOOD_LOSS)
    return train_and_predict(ar, csv_file_name, training_steps=600)

def train_and_predict(estimator, csv_file_name, training_steps):
    data = pd.read_csv(csv_file_name, header=0)
    data['timestamp'] = data['timestamp'].apply(lambda x: date_conversion(x))
    reader = tf.contrib.timeseries.NumpyReader(data={tf.contrib.timeseries.TrainEvalFeatures.TIMES: data['timestamp'].values, tf.contrib.timeseries.TrainEvalFeatures.VALUES : data['values'].values})
    #reader = tf.contrib.timeseries.CSVReader(csv_file_name)
    # Set up windowing and batching for training
    train_input_fn = tf.contrib.timeseries.RandomWindowInputFn(reader, batch_size=16, window_size=4)
    # Fit model parameters to data
    estimator.train(input_fn=train_input_fn, steps=training_steps)
    # Evaluate on the full dataset sequentially, collecting in-sample predictions
    # for a qualitative evaluation. Note that this loads the whole dataset into
    # memory. For quantitative evaluation, use RandomWindowChunker.
    evaluation_input_fn = tf.contrib.timeseries.WholeDatasetInputFn(reader)
    evaluation = estimator.evaluate(input_fn=evaluation_input_fn, steps=1)
    # Predict starting after the evaluation
    (predictions,) = tuple(estimator.predict(input_fn=tf.contrib.timeseries.predict_continuation_input_fn(evaluation, steps=1000)))
    times = evaluation["times"][0]
    observed = evaluation["observed"][0, :, 0]
    mean = np.squeeze(np.concatenate([evaluation["mean"][0], predictions["mean"]], axis=0))
    variance = np.squeeze(np.concatenate([evaluation["covariance"][0], predictions["covariance"]], axis=0))
    all_times = np.concatenate([times, predictions["times"]], axis=0)
    upper_limit = mean + np.sqrt(variance)
    lower_limit = mean - np.sqrt(variance)
    return times, observed, all_times, mean, upper_limit, lower_limit

def make_plot(name, training_times, observed, all_times, mean,upper_limit, lower_limit):
    plt.figure()
    plt.plot(training_times, observed, "b", label="training series")
    plt.plot(all_times, mean, "r", label="forecast")
    plt.plot(all_times, upper_limit, "g", label="forecast upper bound")
    plt.plot(all_times, lower_limit, "g", label="forecast lower bound")
    plt.fill_between(all_times, lower_limit, upper_limit, color="grey",alpha="0.2")
    plt.axvline(training_times[-1], color="k", linestyle="--")
    plt.xlabel("time")
    plt.ylabel("observations")
    plt.legend(loc=0)
    plt.title(name)
    

def tensorflow_dataframe(temp_df):
    b = temp_df.groupby(['created_at'])['created_at']
    b1 = b.describe()
    temp = pd.DataFrame()
    temp = b1[['top', 'count']]
    temp.columns = ['timestamp', 'values']
    columns = [x for x in temp.columns]
    datatowrite = temp[columns]
    return datatowrite

tensorflow_dataframe(issuesdf).to_csv('tensorflow_issues_create.csv', sep=',', encoding='utf-8',index=False)
make_plot("Issues Created Tensorflow", *ar_train_and_predict("tensorflow_issues_create.csv"))
plt.show()
```

    INFO:tensorflow:Using default config.
    

    INFO:tensorflow:Using default config.
    

    WARNING:tensorflow:Using temporary folder as model directory: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi
    

    WARNING:tensorflow:Using temporary folder as model directory: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi
    

    INFO:tensorflow:Using config: {'_model_dir': '/var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi', '_tf_random_seed': None, '_save_summary_steps': 100, '_save_checkpoints_steps': None, '_save_checkpoints_secs': 600, '_session_config': allow_soft_placement: true
    graph_options {
      rewrite_options {
        meta_optimizer_iterations: ONE
      }
    }
    , '_keep_checkpoint_max': 5, '_keep_checkpoint_every_n_hours': 10000, '_log_step_count_steps': 100, '_train_distribute': None, '_device_fn': None, '_protocol': None, '_eval_distribute': None, '_experimental_distribute': None, '_experimental_max_worker_delay_secs': None, '_service': None, '_cluster_spec': <tensorflow.python.training.server_lib.ClusterSpec object at 0x7fbf1989bf90>, '_task_type': 'worker', '_task_id': 0, '_global_id_in_cluster': 0, '_master': '', '_evaluation_master': '', '_is_chief': True, '_num_ps_replicas': 0, '_num_worker_replicas': 1}
    

    INFO:tensorflow:Using config: {'_model_dir': '/var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi', '_tf_random_seed': None, '_save_summary_steps': 100, '_save_checkpoints_steps': None, '_save_checkpoints_secs': 600, '_session_config': allow_soft_placement: true
    graph_options {
      rewrite_options {
        meta_optimizer_iterations: ONE
      }
    }
    , '_keep_checkpoint_max': 5, '_keep_checkpoint_every_n_hours': 10000, '_log_step_count_steps': 100, '_train_distribute': None, '_device_fn': None, '_protocol': None, '_eval_distribute': None, '_experimental_distribute': None, '_experimental_max_worker_delay_secs': None, '_service': None, '_cluster_spec': <tensorflow.python.training.server_lib.ClusterSpec object at 0x7fbf1989bf90>, '_task_type': 'worker', '_task_id': 0, '_global_id_in_cluster': 0, '_master': '', '_evaluation_master': '', '_is_chief': True, '_num_ps_replicas': 0, '_num_worker_replicas': 1}
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf17d10c50>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf17d10c50>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf17d10c50>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf17d10c50>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf17d10c50>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf17d10c50>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Create CheckpointSaverHook.
    

    INFO:tensorflow:Create CheckpointSaverHook.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Saving checkpoints for 0 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt.
    

    INFO:tensorflow:Saving checkpoints for 0 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt.
    

    INFO:tensorflow:loss = 1.5443797, step = 1
    

    INFO:tensorflow:loss = 1.5443797, step = 1
    

    INFO:tensorflow:global_step/sec: 635.724
    

    INFO:tensorflow:global_step/sec: 635.724
    

    INFO:tensorflow:loss = 1.0433427, step = 101 (0.159 sec)
    

    INFO:tensorflow:loss = 1.0433427, step = 101 (0.159 sec)
    

    INFO:tensorflow:global_step/sec: 1243.67
    

    INFO:tensorflow:global_step/sec: 1243.67
    

    INFO:tensorflow:loss = 0.88014513, step = 201 (0.081 sec)
    

    INFO:tensorflow:loss = 0.88014513, step = 201 (0.081 sec)
    

    INFO:tensorflow:global_step/sec: 1250.92
    

    INFO:tensorflow:global_step/sec: 1250.92
    

    INFO:tensorflow:loss = 0.9834051, step = 301 (0.079 sec)
    

    INFO:tensorflow:loss = 0.9834051, step = 301 (0.079 sec)
    

    INFO:tensorflow:global_step/sec: 1614.42
    

    INFO:tensorflow:global_step/sec: 1614.42
    

    INFO:tensorflow:loss = 0.95913965, step = 401 (0.062 sec)
    

    INFO:tensorflow:loss = 0.95913965, step = 401 (0.062 sec)
    

    INFO:tensorflow:global_step/sec: 1426.58
    

    INFO:tensorflow:global_step/sec: 1426.58
    

    INFO:tensorflow:loss = 1.7004888, step = 501 (0.071 sec)
    

    INFO:tensorflow:loss = 1.7004888, step = 501 (0.071 sec)
    

    INFO:tensorflow:Saving checkpoints for 600 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt.
    

    INFO:tensorflow:Saving checkpoints for 600 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt.
    

    INFO:tensorflow:Loss for final step: 0.8988972.
    

    INFO:tensorflow:Loss for final step: 0.8988972.
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1621fe10>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1621fe10>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1621fe10>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1621fe10>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1621fe10>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1621fe10>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Starting evaluation at 2020-12-01T22:08:10Z
    

    INFO:tensorflow:Starting evaluation at 2020-12-01T22:08:10Z
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt-600
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt-600
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Evaluation [1/1]
    

    INFO:tensorflow:Evaluation [1/1]
    

    INFO:tensorflow:Finished evaluation at 2020-12-01-22:08:10
    

    INFO:tensorflow:Finished evaluation at 2020-12-01-22:08:10
    

    INFO:tensorflow:Saving dict for global step 600: average_loss = 1.0688831, covariance = [[[  42.888985]
      [  83.02664 ]
      [  42.888985]
      [  83.02664 ]
      [  35.509346]
      [  68.56391 ]
      [  40.27276 ]
      [  77.89511 ]
      [  29.517265]
      [  63.874847]
      [  31.434782]
      [  68.08276 ]
      [  29.867281]
      [  63.153893]
      [ 195.03244 ]
      [ 433.06073 ]
      [1083.23    ]
      [ 883.23706 ]
      [1371.5198  ]
      [1022.0685  ]
      [ 408.313   ]
      [ 272.6559  ]
      [ 347.58072 ]
      [ 360.56866 ]
      [ 180.9143  ]
      [ 194.88329 ]
      [  33.866817]
      [  49.41017 ]
      [  27.391903]
      [  60.611126]
      [  35.23381 ]
      [  78.23148 ]
      [ 135.78969 ]
      [ 226.84698 ]
      [  35.779625]
      [  41.38198 ]
      [  30.702328]
      [  69.646095]
      [  33.873837]
      [  71.74881 ]
      [  31.807535]
      [  67.31431 ]
      [  45.675163]
      [  88.49623 ]
      [  49.21914 ]
      [  93.261475]
      [  53.667027]
      [  97.17399 ]
      [  63.05724 ]
      [ 106.702675]
      [  63.05724 ]
      [ 106.702675]
      [  31.184402]
      [  53.49643 ]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  31.066397]
      [  68.85999 ]
      [  36.934982]
      [  74.75883 ]
      [  41.889633]
      [  84.93311 ]
      [  53.667027]
      [  97.17399 ]
      [  42.888985]
      [  83.02664 ]
      [  42.386364]
      [  83.97447 ]
      [  27.606112]
      [  53.12102 ]
      [  25.419573]
      [  57.514168]
      [  39.8008  ]
      [  78.784355]
      [  53.667027]
      [  97.17399 ]
      [  31.807535]
      [  67.31431 ]
      [  34.275513]
      [  70.93898 ]
      [  53.250595]
      [ 110.87561 ]
      [  27.391903]
      [  60.611126]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  27.391903]
      [  60.611126]
      [  35.23381 ]
      [  78.23148 ]
      [  39.334373]
      [  79.68375 ]
      [  42.888985]
      [  83.02664 ]
      [  39.8008  ]
      [  78.784355]
      [  39.8008  ]
      [  78.784355]
      [  35.09321 ]
      [  69.346634]
      [  34.275513]
      [  70.93898 ]
      [  27.391903]
      [  60.611126]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  27.391903]
      [  60.611126]
      [  31.066397]
      [  68.85999 ]
      [  31.807535]
      [  67.31431 ]
      [  38.41785 ]
      [  81.51346 ]
      [  37.372955]
      [  73.915016]
      [  34.275513]
      [  70.93898 ]
      [  42.888985]
      [  83.02664 ]
      [  43.912167]
      [  81.16297 ]
      [  42.888985]
      [  83.02664 ]
      [  45.675163]
      [  88.49623 ]
      [  39.8008  ]
      [  78.784355]
      [  39.334373]
      [  79.68375 ]
      [  30.942427]
      [  61.039474]
      [  27.391903]
      [  60.611126]
      [  25.419573]
      [  57.514168]
      [  27.07089 ]
      [  61.303062]
      [  31.066397]
      [  68.85999 ]
      [  29.517265]
      [  63.874847]
      [  29.517265]
      [  63.874847]
      [  33.873837]
      [  71.74881 ]
      [  36.50214 ]
      [  75.61227 ]
      [  33.873837]
      [  71.74881 ]
      [  29.867281]
      [  63.153893]
      [  29.517265]
      [  63.874847]
      [  31.807535]
      [  67.31431 ]
      [  25.419573]
      [  57.514168]
      [  36.78759 ]
      [  66.268364]
      [  34.275513]
      [  70.93898 ]
      [  36.50214 ]
      [  75.61227 ]
      [  29.517265]
      [  63.874847]
      [  31.807535]
      [  67.31431 ]
      [  33.873837]
      [  71.74881 ]
      [  28.377941]
      [  58.58185 ]
      [ 436.67065 ]
      [ 476.0766  ]
      [  66.632515]
      [ 129.76828 ]
      [  41.06899 ]
      [  67.49855 ]
      [  56.698143]
      [  81.38511 ]
      [  40.27276 ]
      [  77.89511 ]
      [ 106.79699 ]
      [ 119.66737 ]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  40.750313]
      [  77.0159  ]
      [  29.517265]
      [  63.874847]
      [  53.667027]
      [  97.17399 ]
      [  64.82024 ]
      [ 117.67168 ]
      [  43.22438 ]
      [  72.7665  ]
      [  25.419573]
      [  57.514168]
      [  31.807535]
      [  67.31431 ]
      [  39.8008  ]
      [  78.784355]
      [  29.28216 ]
      [  50.19004 ]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  27.391903]
      [  60.611126]
      [  48.2649  ]
      [ 107.626205]
      [  53.667027]
      [  97.17399 ]
      [  53.667027]
      [  97.17399 ]
      [  34.543556]
      [  62.17259 ]
      [  25.720997]
      [  56.865   ]
      [  39.491962]
      [  89.89301 ]
      [  42.888985]
      [  83.02664 ]
      [  42.888985]
      [  83.02664 ]
      [  45.675163]
      [  88.49623 ]
      [  43.39756 ]
      [  82.089516]
      [  42.888985]
      [  83.02664 ]
      [  42.888985]
      [  83.02664 ]
      [  37.816124]
      [  73.080734]
      [  32.184708]
      [  66.554535]
      [  29.517265]
      [  63.874847]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]]], global_step = 600, loss = 1.0688831, mean = [[[ 7.6161876]
      [ 7.5138483]
      [ 7.6161876]
      [ 7.5138483]
      [ 5.240141 ]
      [ 5.797288 ]
      [ 6.824172 ]
      [ 6.941662 ]
      [ 3.6072576]
      [ 4.4687567]
      [ 4.399273 ]
      [ 5.040943 ]
      [ 3.617028 ]
      [ 4.5055885]
      [27.367722 ]
      [21.634365 ]
      [42.84592  ]
      [34.1265   ]
      [45.261047 ]
      [35.990387 ]
      [29.459824 ]
      [24.693974 ]
      [30.066196 ]
      [24.566364 ]
      [22.1265   ]
      [18.770832 ]
      [ 2.9813418]
      [ 4.522705 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 5.973533 ]
      [ 6.1484857]
      [21.148844 ]
      [17.498846 ]
      [ 2.2870321]
      [ 4.3188324]
      [ 4.3797317]
      [ 4.9672804]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 4.4090433]
      [ 5.077775 ]
      [ 8.408203 ]
      [ 8.086036 ]
      [ 9.209989 ]
      [ 8.695054 ]
      [10.021545 ]
      [ 9.340904 ]
      [11.634889 ]
      [10.595772 ]
      [11.634889 ]
      [10.595772 ]
      [ 2.9129477]
      [ 4.2648845]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 4.3895025]
      [ 5.0041122]
      [ 6.012615 ]
      [ 6.2958117]
      [ 7.5966463]
      [ 7.4401855]
      [10.021545 ]
      [ 9.340904 ]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.606417 ]
      [ 7.477017 ]
      [ 2.0720797]
      [ 3.5085404]
      [ 2.0036855]
      [ 3.2507198]
      [ 6.8144016]
      [ 6.90483  ]
      [10.021545 ]
      [ 9.340904 ]
      [ 4.4090433]
      [ 5.077775 ]
      [ 5.2108297]
      [ 5.6867933]
      [10.754938 ]
      [ 9.6921015]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.8054714]
      [ 3.859738 ]
      [ 5.973533 ]
      [ 6.1484857]
      [ 6.8046308]
      [ 6.8679986]
      [ 7.6161876]
      [ 7.5138483]
      [ 6.8144016]
      [ 6.90483  ]
      [ 6.8144016]
      [ 6.90483  ]
      [ 5.2303705]
      [ 5.760456 ]
      [ 5.2108297]
      [ 5.6867933]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.8054714]
      [ 3.859738 ]
      [ 4.3895025]
      [ 5.0041122]
      [ 4.4090433]
      [ 5.077775 ]
      [ 6.78509  ]
      [ 6.794336 ]
      [ 6.022386 ]
      [ 6.332643 ]
      [ 5.2108297]
      [ 5.6867933]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.635729 ]
      [ 7.5875115]
      [ 7.6161876]
      [ 7.5138483]
      [ 8.408203 ]
      [ 8.086036 ]
      [ 6.8144016]
      [ 6.90483  ]
      [ 6.8046308]
      [ 6.8679986]
      [ 3.64634  ]
      [ 4.6160827]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.7957006]
      [ 3.8229067]
      [ 4.3895025]
      [ 5.0041122]
      [ 3.6072576]
      [ 4.4687567]
      [ 3.6072576]
      [ 4.4687567]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 6.002845 ]
      [ 6.2589803]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 3.617028 ]
      [ 4.5055885]
      [ 3.6072576]
      [ 4.4687567]
      [ 4.4090433]
      [ 5.077775 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 5.269453 ]
      [ 5.9077826]
      [ 5.2108297]
      [ 5.6867933]
      [ 6.002845 ]
      [ 6.2589803]
      [ 3.6072576]
      [ 4.4687567]
      [ 4.4090433]
      [ 5.077775 ]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 2.834783 ]
      [ 3.9702325]
      [33.214718 ]
      [26.781448 ]
      [13.1602955]
      [11.519157 ]
      [ 6.1005507]
      [ 6.627295 ]
      [ 9.327236 ]
      [ 9.137032 ]
      [ 6.824172 ]
      [ 6.941662 ]
      [15.770836 ]
      [14.119673 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 6.833943 ]
      [ 6.978493 ]
      [ 3.6072576]
      [ 4.4687567]
      [10.021545 ]
      [ 9.340904 ]
      [12.397593 ]
      [11.057465 ]
      [ 6.8827953]
      [ 7.1626506]
      [ 2.0036855]
      [ 3.2507198]
      [ 4.4090433]
      [ 5.077775 ]
      [ 6.8144016]
      [ 6.90483  ]
      [ 2.120932 ]
      [ 3.6926975]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.8054714]
      [ 3.859738 ]
      [ 9.933611 ]
      [ 9.00942  ]
      [10.021545 ]
      [ 9.340904 ]
      [10.021545 ]
      [ 9.340904 ]
      [ 4.477438 ]
      [ 5.335595 ]
      [ 2.0134559]
      [ 3.2875512]
      [ 7.5477934]
      [ 7.256028 ]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.6161876]
      [ 7.5138483]
      [ 8.408203 ]
      [ 8.086036 ]
      [ 7.625958 ]
      [ 7.55068  ]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.6161876]
      [ 7.5138483]
      [ 6.0321565]
      [ 6.369475 ]
      [ 4.4188137]
      [ 5.1146064]
      [ 3.6072576]
      [ 4.4687567]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]]], observed = [[[ 8.]
      [ 8.]
      [ 8.]
      [ 5.]
      [ 8.]
      [ 7.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 3.]
      [ 3.]
      [33.]
      [47.]
      [52.]
      [51.]
      [55.]
      [55.]
      [35.]
      [36.]
      [36.]
      [34.]
      [26.]
      [20.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 6.]
      [15.]
      [25.]
      [30.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 8.]
      [ 9.]
      [ 9.]
      [10.]
      [11.]
      [11.]
      [14.]
      [13.]
      [14.]
      [13.]
      [13.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 6.]
      [ 6.]
      [ 6.]
      [ 8.]
      [11.]
      [11.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 7.]
      [ 7.]
      [11.]
      [11.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 5.]
      [12.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 6.]
      [ 6.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 5.]
      [ 5.]
      [ 8.]
      [ 8.]
      [10.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 7.]
      [ 7.]
      [ 3.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 1.]
      [ 1.]
      [11.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 2.]
      [34.]
      [40.]
      [ 8.]
      [15.]
      [15.]
      [ 6.]
      [21.]
      [10.]
      [ 8.]
      [ 7.]
      [32.]
      [18.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 9.]
      [ 7.]
      [ 3.]
      [ 3.]
      [11.]
      [11.]
      [11.]
      [14.]
      [14.]
      [ 7.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [13.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [ 4.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 9.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 6.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]]], start_tuple = (array([[1506661200, 1506747600]]), array([[[-0.65989697],
            [-0.65989697]]], dtype=float32), array([], shape=(1, 2, 0), dtype=float32)), times = [[1483768800 1483855200 1483941600 1484028000 1484114400 1484200800
      1486360800 1486447200 1486533600 1486620000 1486706400 1486792800
      1486879200 1488348000 1488434400 1488520800 1488607200 1488693600
      1488780000 1488866400 1488952800 1489039200 1489125600 1489212000
      1489298400 1491368400 1491454800 1491541200 1491627600 1491714000
      1491800400 1491886800 1491973200 1493787600 1493874000 1493960400
      1494046800 1494133200 1494219600 1494306000 1494392400 1494478800
      1494565200 1496638800 1496725200 1496811600 1496898000 1496984400
      1497070800 1497157200 1497243600 1498885200 1498971600 1499058000
      1499144400 1499230800 1499317200 1499403600 1499490000 1499576400
      1499662800 1499749200 1499835600 1501563600 1501650000 1501736400
      1501822800 1501909200 1501995600 1502082000 1502168400 1502254800
      1502341200 1502427600 1502514000 1504242000 1504328400 1505192400
      1484287200 1484373600 1484460000 1484546400 1484632800 1484719200
      1484805600 1484892000 1484978400 1485064800 1506834000 1506920400
      1507006800 1507093200 1507179600 1507266000 1507352400 1507438800
      1507525200 1507611600 1507698000 1507784400 1507870800 1507957200
      1508043600 1508130000 1508216400 1508302800 1508389200 1508475600
      1508562000 1508648400 1508734800 1508821200 1508907600 1508994000
      1509080400 1509166800 1509253200 1509339600 1509512400 1509598800
      1509685200 1509771600 1509858000 1509948000 1510034400 1510120800
      1510207200 1510293600 1510380000 1510466400 1510552800 1510639200
      1510725600 1510812000 1510898400 1510984800 1511071200 1511157600
      1511244000 1511330400 1511416800 1511503200 1511589600 1511676000
      1511762400 1511848800 1511935200 1512021600 1512108000 1512194400
      1512280800 1512367200 1512453600 1512540000 1512626400 1512712800
      1512799200 1512885600 1512972000 1513058400 1513144800 1513231200
      1513317600 1513404000 1513490400 1513576800 1513663200 1513749600
      1513836000 1513922400 1486965600 1487052000 1487138400 1487224800
      1487311200 1487397600 1487484000 1487570400 1487656800 1487743200
      1487829600 1487916000 1488002400 1488088800 1488175200 1488261600
      1489381200 1489467600 1489554000 1489640400 1489726800 1489813200
      1489899600 1489986000 1492059600 1492146000 1492232400 1492318800
      1492405200 1492491600 1492578000 1492664400 1492750800 1492837200
      1494651600 1494738000 1494824400 1494910800 1494997200 1495083600
      1495170000 1495256400 1495342800 1495429200 1495515600 1495602000
      1495688400 1495774800 1495861200 1495947600 1497330000 1497416400
      1497502800 1497589200 1497675600 1497762000 1497848400 1497934800
      1498021200 1498107600 1498194000 1498280400 1498366800 1498453200
      1498539600 1498626000 1499922000 1500008400 1500094800 1500181200
      1500267600 1500354000 1500440400 1500526800 1500613200 1500699600
      1500786000 1500872400 1500958800 1502600400 1502686800 1502773200
      1502859600 1502946000 1503032400 1503118800 1503205200 1503291600
      1503378000 1503464400 1503550800 1503637200 1503723600 1503810000
      1503896400 1503982800 1504069200 1504155600 1505278800 1505365200
      1505451600 1505538000 1505624400 1505710800 1505797200 1505883600
      1505970000 1506056400 1506142800 1506229200 1506315600 1506402000
      1506488400 1506574800 1506661200 1506747600]]
    

    INFO:tensorflow:Saving dict for global step 600: average_loss = 1.0688831, covariance = [[[  42.888985]
      [  83.02664 ]
      [  42.888985]
      [  83.02664 ]
      [  35.509346]
      [  68.56391 ]
      [  40.27276 ]
      [  77.89511 ]
      [  29.517265]
      [  63.874847]
      [  31.434782]
      [  68.08276 ]
      [  29.867281]
      [  63.153893]
      [ 195.03244 ]
      [ 433.06073 ]
      [1083.23    ]
      [ 883.23706 ]
      [1371.5198  ]
      [1022.0685  ]
      [ 408.313   ]
      [ 272.6559  ]
      [ 347.58072 ]
      [ 360.56866 ]
      [ 180.9143  ]
      [ 194.88329 ]
      [  33.866817]
      [  49.41017 ]
      [  27.391903]
      [  60.611126]
      [  35.23381 ]
      [  78.23148 ]
      [ 135.78969 ]
      [ 226.84698 ]
      [  35.779625]
      [  41.38198 ]
      [  30.702328]
      [  69.646095]
      [  33.873837]
      [  71.74881 ]
      [  31.807535]
      [  67.31431 ]
      [  45.675163]
      [  88.49623 ]
      [  49.21914 ]
      [  93.261475]
      [  53.667027]
      [  97.17399 ]
      [  63.05724 ]
      [ 106.702675]
      [  63.05724 ]
      [ 106.702675]
      [  31.184402]
      [  53.49643 ]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  31.066397]
      [  68.85999 ]
      [  36.934982]
      [  74.75883 ]
      [  41.889633]
      [  84.93311 ]
      [  53.667027]
      [  97.17399 ]
      [  42.888985]
      [  83.02664 ]
      [  42.386364]
      [  83.97447 ]
      [  27.606112]
      [  53.12102 ]
      [  25.419573]
      [  57.514168]
      [  39.8008  ]
      [  78.784355]
      [  53.667027]
      [  97.17399 ]
      [  31.807535]
      [  67.31431 ]
      [  34.275513]
      [  70.93898 ]
      [  53.250595]
      [ 110.87561 ]
      [  27.391903]
      [  60.611126]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  27.391903]
      [  60.611126]
      [  35.23381 ]
      [  78.23148 ]
      [  39.334373]
      [  79.68375 ]
      [  42.888985]
      [  83.02664 ]
      [  39.8008  ]
      [  78.784355]
      [  39.8008  ]
      [  78.784355]
      [  35.09321 ]
      [  69.346634]
      [  34.275513]
      [  70.93898 ]
      [  27.391903]
      [  60.611126]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  27.391903]
      [  60.611126]
      [  31.066397]
      [  68.85999 ]
      [  31.807535]
      [  67.31431 ]
      [  38.41785 ]
      [  81.51346 ]
      [  37.372955]
      [  73.915016]
      [  34.275513]
      [  70.93898 ]
      [  42.888985]
      [  83.02664 ]
      [  43.912167]
      [  81.16297 ]
      [  42.888985]
      [  83.02664 ]
      [  45.675163]
      [  88.49623 ]
      [  39.8008  ]
      [  78.784355]
      [  39.334373]
      [  79.68375 ]
      [  30.942427]
      [  61.039474]
      [  27.391903]
      [  60.611126]
      [  25.419573]
      [  57.514168]
      [  27.07089 ]
      [  61.303062]
      [  31.066397]
      [  68.85999 ]
      [  29.517265]
      [  63.874847]
      [  29.517265]
      [  63.874847]
      [  33.873837]
      [  71.74881 ]
      [  36.50214 ]
      [  75.61227 ]
      [  33.873837]
      [  71.74881 ]
      [  29.867281]
      [  63.153893]
      [  29.517265]
      [  63.874847]
      [  31.807535]
      [  67.31431 ]
      [  25.419573]
      [  57.514168]
      [  36.78759 ]
      [  66.268364]
      [  34.275513]
      [  70.93898 ]
      [  36.50214 ]
      [  75.61227 ]
      [  29.517265]
      [  63.874847]
      [  31.807535]
      [  67.31431 ]
      [  33.873837]
      [  71.74881 ]
      [  28.377941]
      [  58.58185 ]
      [ 436.67065 ]
      [ 476.0766  ]
      [  66.632515]
      [ 129.76828 ]
      [  41.06899 ]
      [  67.49855 ]
      [  56.698143]
      [  81.38511 ]
      [  40.27276 ]
      [  77.89511 ]
      [ 106.79699 ]
      [ 119.66737 ]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  27.391903]
      [  60.611126]
      [  40.750313]
      [  77.0159  ]
      [  29.517265]
      [  63.874847]
      [  53.667027]
      [  97.17399 ]
      [  64.82024 ]
      [ 117.67168 ]
      [  43.22438 ]
      [  72.7665  ]
      [  25.419573]
      [  57.514168]
      [  31.807535]
      [  67.31431 ]
      [  39.8008  ]
      [  78.784355]
      [  29.28216 ]
      [  50.19004 ]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  27.391903]
      [  60.611126]
      [  48.2649  ]
      [ 107.626205]
      [  53.667027]
      [  97.17399 ]
      [  53.667027]
      [  97.17399 ]
      [  34.543556]
      [  62.17259 ]
      [  25.720997]
      [  56.865   ]
      [  39.491962]
      [  89.89301 ]
      [  42.888985]
      [  83.02664 ]
      [  42.888985]
      [  83.02664 ]
      [  45.675163]
      [  88.49623 ]
      [  43.39756 ]
      [  82.089516]
      [  42.888985]
      [  83.02664 ]
      [  42.888985]
      [  83.02664 ]
      [  37.816124]
      [  73.080734]
      [  32.184708]
      [  66.554535]
      [  29.517265]
      [  63.874847]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]
      [  25.419573]
      [  57.514168]]], global_step = 600, loss = 1.0688831, mean = [[[ 7.6161876]
      [ 7.5138483]
      [ 7.6161876]
      [ 7.5138483]
      [ 5.240141 ]
      [ 5.797288 ]
      [ 6.824172 ]
      [ 6.941662 ]
      [ 3.6072576]
      [ 4.4687567]
      [ 4.399273 ]
      [ 5.040943 ]
      [ 3.617028 ]
      [ 4.5055885]
      [27.367722 ]
      [21.634365 ]
      [42.84592  ]
      [34.1265   ]
      [45.261047 ]
      [35.990387 ]
      [29.459824 ]
      [24.693974 ]
      [30.066196 ]
      [24.566364 ]
      [22.1265   ]
      [18.770832 ]
      [ 2.9813418]
      [ 4.522705 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 5.973533 ]
      [ 6.1484857]
      [21.148844 ]
      [17.498846 ]
      [ 2.2870321]
      [ 4.3188324]
      [ 4.3797317]
      [ 4.9672804]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 4.4090433]
      [ 5.077775 ]
      [ 8.408203 ]
      [ 8.086036 ]
      [ 9.209989 ]
      [ 8.695054 ]
      [10.021545 ]
      [ 9.340904 ]
      [11.634889 ]
      [10.595772 ]
      [11.634889 ]
      [10.595772 ]
      [ 2.9129477]
      [ 4.2648845]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 4.3895025]
      [ 5.0041122]
      [ 6.012615 ]
      [ 6.2958117]
      [ 7.5966463]
      [ 7.4401855]
      [10.021545 ]
      [ 9.340904 ]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.606417 ]
      [ 7.477017 ]
      [ 2.0720797]
      [ 3.5085404]
      [ 2.0036855]
      [ 3.2507198]
      [ 6.8144016]
      [ 6.90483  ]
      [10.021545 ]
      [ 9.340904 ]
      [ 4.4090433]
      [ 5.077775 ]
      [ 5.2108297]
      [ 5.6867933]
      [10.754938 ]
      [ 9.6921015]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.8054714]
      [ 3.859738 ]
      [ 5.973533 ]
      [ 6.1484857]
      [ 6.8046308]
      [ 6.8679986]
      [ 7.6161876]
      [ 7.5138483]
      [ 6.8144016]
      [ 6.90483  ]
      [ 6.8144016]
      [ 6.90483  ]
      [ 5.2303705]
      [ 5.760456 ]
      [ 5.2108297]
      [ 5.6867933]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.8054714]
      [ 3.859738 ]
      [ 4.3895025]
      [ 5.0041122]
      [ 4.4090433]
      [ 5.077775 ]
      [ 6.78509  ]
      [ 6.794336 ]
      [ 6.022386 ]
      [ 6.332643 ]
      [ 5.2108297]
      [ 5.6867933]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.635729 ]
      [ 7.5875115]
      [ 7.6161876]
      [ 7.5138483]
      [ 8.408203 ]
      [ 8.086036 ]
      [ 6.8144016]
      [ 6.90483  ]
      [ 6.8046308]
      [ 6.8679986]
      [ 3.64634  ]
      [ 4.6160827]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.7957006]
      [ 3.8229067]
      [ 4.3895025]
      [ 5.0041122]
      [ 3.6072576]
      [ 4.4687567]
      [ 3.6072576]
      [ 4.4687567]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 6.002845 ]
      [ 6.2589803]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 3.617028 ]
      [ 4.5055885]
      [ 3.6072576]
      [ 4.4687567]
      [ 4.4090433]
      [ 5.077775 ]
      [ 2.0036855]
      [ 3.2507198]
      [ 5.269453 ]
      [ 5.9077826]
      [ 5.2108297]
      [ 5.6867933]
      [ 6.002845 ]
      [ 6.2589803]
      [ 3.6072576]
      [ 4.4687567]
      [ 4.4090433]
      [ 5.077775 ]
      [ 5.201059 ]
      [ 5.649962 ]
      [ 2.834783 ]
      [ 3.9702325]
      [33.214718 ]
      [26.781448 ]
      [13.1602955]
      [11.519157 ]
      [ 6.1005507]
      [ 6.627295 ]
      [ 9.327236 ]
      [ 9.137032 ]
      [ 6.824172 ]
      [ 6.941662 ]
      [15.770836 ]
      [14.119673 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 2.8054714]
      [ 3.859738 ]
      [ 6.833943 ]
      [ 6.978493 ]
      [ 3.6072576]
      [ 4.4687567]
      [10.021545 ]
      [ 9.340904 ]
      [12.397593 ]
      [11.057465 ]
      [ 6.8827953]
      [ 7.1626506]
      [ 2.0036855]
      [ 3.2507198]
      [ 4.4090433]
      [ 5.077775 ]
      [ 6.8144016]
      [ 6.90483  ]
      [ 2.120932 ]
      [ 3.6926975]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.8054714]
      [ 3.859738 ]
      [ 9.933611 ]
      [ 9.00942  ]
      [10.021545 ]
      [ 9.340904 ]
      [10.021545 ]
      [ 9.340904 ]
      [ 4.477438 ]
      [ 5.335595 ]
      [ 2.0134559]
      [ 3.2875512]
      [ 7.5477934]
      [ 7.256028 ]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.6161876]
      [ 7.5138483]
      [ 8.408203 ]
      [ 8.086036 ]
      [ 7.625958 ]
      [ 7.55068  ]
      [ 7.6161876]
      [ 7.5138483]
      [ 7.6161876]
      [ 7.5138483]
      [ 6.0321565]
      [ 6.369475 ]
      [ 4.4188137]
      [ 5.1146064]
      [ 3.6072576]
      [ 4.4687567]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]
      [ 2.0036855]
      [ 3.2507198]]], observed = [[[ 8.]
      [ 8.]
      [ 8.]
      [ 5.]
      [ 8.]
      [ 7.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 3.]
      [ 3.]
      [33.]
      [47.]
      [52.]
      [51.]
      [55.]
      [55.]
      [35.]
      [36.]
      [36.]
      [34.]
      [26.]
      [20.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 6.]
      [15.]
      [25.]
      [30.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 8.]
      [ 9.]
      [ 9.]
      [10.]
      [11.]
      [11.]
      [14.]
      [13.]
      [14.]
      [13.]
      [13.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 6.]
      [ 6.]
      [ 6.]
      [ 8.]
      [11.]
      [11.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 7.]
      [ 7.]
      [11.]
      [11.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 5.]
      [12.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 6.]
      [ 6.]
      [ 7.]
      [ 8.]
      [ 8.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 7.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 5.]
      [ 5.]
      [ 8.]
      [ 8.]
      [10.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 7.]
      [ 7.]
      [ 6.]
      [ 7.]
      [ 7.]
      [ 3.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 1.]
      [ 1.]
      [11.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 5.]
      [ 6.]
      [ 3.]
      [ 3.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 2.]
      [34.]
      [40.]
      [ 8.]
      [15.]
      [15.]
      [ 6.]
      [21.]
      [10.]
      [ 8.]
      [ 7.]
      [32.]
      [18.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 9.]
      [ 7.]
      [ 3.]
      [ 3.]
      [11.]
      [11.]
      [11.]
      [14.]
      [14.]
      [ 7.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 4.]
      [ 7.]
      [ 7.]
      [13.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [11.]
      [ 4.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 9.]
      [ 9.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 8.]
      [ 6.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]]], start_tuple = (array([[1506661200, 1506747600]]), array([[[-0.65989697],
            [-0.65989697]]], dtype=float32), array([], shape=(1, 2, 0), dtype=float32)), times = [[1483768800 1483855200 1483941600 1484028000 1484114400 1484200800
      1486360800 1486447200 1486533600 1486620000 1486706400 1486792800
      1486879200 1488348000 1488434400 1488520800 1488607200 1488693600
      1488780000 1488866400 1488952800 1489039200 1489125600 1489212000
      1489298400 1491368400 1491454800 1491541200 1491627600 1491714000
      1491800400 1491886800 1491973200 1493787600 1493874000 1493960400
      1494046800 1494133200 1494219600 1494306000 1494392400 1494478800
      1494565200 1496638800 1496725200 1496811600 1496898000 1496984400
      1497070800 1497157200 1497243600 1498885200 1498971600 1499058000
      1499144400 1499230800 1499317200 1499403600 1499490000 1499576400
      1499662800 1499749200 1499835600 1501563600 1501650000 1501736400
      1501822800 1501909200 1501995600 1502082000 1502168400 1502254800
      1502341200 1502427600 1502514000 1504242000 1504328400 1505192400
      1484287200 1484373600 1484460000 1484546400 1484632800 1484719200
      1484805600 1484892000 1484978400 1485064800 1506834000 1506920400
      1507006800 1507093200 1507179600 1507266000 1507352400 1507438800
      1507525200 1507611600 1507698000 1507784400 1507870800 1507957200
      1508043600 1508130000 1508216400 1508302800 1508389200 1508475600
      1508562000 1508648400 1508734800 1508821200 1508907600 1508994000
      1509080400 1509166800 1509253200 1509339600 1509512400 1509598800
      1509685200 1509771600 1509858000 1509948000 1510034400 1510120800
      1510207200 1510293600 1510380000 1510466400 1510552800 1510639200
      1510725600 1510812000 1510898400 1510984800 1511071200 1511157600
      1511244000 1511330400 1511416800 1511503200 1511589600 1511676000
      1511762400 1511848800 1511935200 1512021600 1512108000 1512194400
      1512280800 1512367200 1512453600 1512540000 1512626400 1512712800
      1512799200 1512885600 1512972000 1513058400 1513144800 1513231200
      1513317600 1513404000 1513490400 1513576800 1513663200 1513749600
      1513836000 1513922400 1486965600 1487052000 1487138400 1487224800
      1487311200 1487397600 1487484000 1487570400 1487656800 1487743200
      1487829600 1487916000 1488002400 1488088800 1488175200 1488261600
      1489381200 1489467600 1489554000 1489640400 1489726800 1489813200
      1489899600 1489986000 1492059600 1492146000 1492232400 1492318800
      1492405200 1492491600 1492578000 1492664400 1492750800 1492837200
      1494651600 1494738000 1494824400 1494910800 1494997200 1495083600
      1495170000 1495256400 1495342800 1495429200 1495515600 1495602000
      1495688400 1495774800 1495861200 1495947600 1497330000 1497416400
      1497502800 1497589200 1497675600 1497762000 1497848400 1497934800
      1498021200 1498107600 1498194000 1498280400 1498366800 1498453200
      1498539600 1498626000 1499922000 1500008400 1500094800 1500181200
      1500267600 1500354000 1500440400 1500526800 1500613200 1500699600
      1500786000 1500872400 1500958800 1502600400 1502686800 1502773200
      1502859600 1502946000 1503032400 1503118800 1503205200 1503291600
      1503378000 1503464400 1503550800 1503637200 1503723600 1503810000
      1503896400 1503982800 1504069200 1504155600 1505278800 1505365200
      1505451600 1505538000 1505624400 1505710800 1505797200 1505883600
      1505970000 1506056400 1506142800 1506229200 1506315600 1506402000
      1506488400 1506574800 1506661200 1506747600]]
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    WARNING:tensorflow:Skipping summary for start_tuple, must be a float, np.float32, np.int64, np.int32 or int or np.ndarray or a serialized string of Summary.
    

    WARNING:tensorflow:Skipping summary for start_tuple, must be a float, np.float32, np.int64, np.int32 or int or np.ndarray or a serialized string of Summary.
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Saving 'checkpoint_path' summary for global step 600: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt-600
    

    INFO:tensorflow:Saving 'checkpoint_path' summary for global step 600: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt-600
    

    WARNING:tensorflow:Input graph does not use tf.data.Dataset or contain a QueueRunner. That means predict yields forever. This is probably a mistake.
    

    WARNING:tensorflow:Input graph does not use tf.data.Dataset or contain a QueueRunner. That means predict yields forever. This is probably a mistake.
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf16319f50>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf16319f50>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf16319f50>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf16319f50>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf16319f50>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf16319f50>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt-600
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpy0_y9lhi/model.ckpt-600
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    


![png](output_35_98.png)



```python
#5. Plot the closed issues forecast : TFTS
def tensorflow_dataframe_closed(temp_df):
    b = temp_df.groupby(['closed_at'])['closed_at']
    b1 = b.describe()
    temp = pd.DataFrame()
    temp = b1[['top', 'count']]
    temp.columns = ['timestamp', 'values']
    columns = [x for x in temp.columns]
    datatowrite = temp[columns]
    return datatowrite

tensorflow_dataframe_closed(issuesdf).to_csv('tensorflow_issues_closed.csv', sep=',', encoding='utf-8',index=False)
make_plot("Issues Closed Tensorflow", *ar_train_and_predict("tensorflow_issues_closed.csv"))
plt.show()

```

    INFO:tensorflow:Using default config.
    

    INFO:tensorflow:Using default config.
    

    WARNING:tensorflow:Using temporary folder as model directory: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4
    

    WARNING:tensorflow:Using temporary folder as model directory: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4
    

    INFO:tensorflow:Using config: {'_model_dir': '/var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4', '_tf_random_seed': None, '_save_summary_steps': 100, '_save_checkpoints_steps': None, '_save_checkpoints_secs': 600, '_session_config': allow_soft_placement: true
    graph_options {
      rewrite_options {
        meta_optimizer_iterations: ONE
      }
    }
    , '_keep_checkpoint_max': 5, '_keep_checkpoint_every_n_hours': 10000, '_log_step_count_steps': 100, '_train_distribute': None, '_device_fn': None, '_protocol': None, '_eval_distribute': None, '_experimental_distribute': None, '_experimental_max_worker_delay_secs': None, '_service': None, '_cluster_spec': <tensorflow.python.training.server_lib.ClusterSpec object at 0x7fbf1a3954d0>, '_task_type': 'worker', '_task_id': 0, '_global_id_in_cluster': 0, '_master': '', '_evaluation_master': '', '_is_chief': True, '_num_ps_replicas': 0, '_num_worker_replicas': 1}
    

    INFO:tensorflow:Using config: {'_model_dir': '/var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4', '_tf_random_seed': None, '_save_summary_steps': 100, '_save_checkpoints_steps': None, '_save_checkpoints_secs': 600, '_session_config': allow_soft_placement: true
    graph_options {
      rewrite_options {
        meta_optimizer_iterations: ONE
      }
    }
    , '_keep_checkpoint_max': 5, '_keep_checkpoint_every_n_hours': 10000, '_log_step_count_steps': 100, '_train_distribute': None, '_device_fn': None, '_protocol': None, '_eval_distribute': None, '_experimental_distribute': None, '_experimental_max_worker_delay_secs': None, '_service': None, '_cluster_spec': <tensorflow.python.training.server_lib.ClusterSpec object at 0x7fbf1a3954d0>, '_task_type': 'worker', '_task_id': 0, '_global_id_in_cluster': 0, '_master': '', '_evaluation_master': '', '_is_chief': True, '_num_ps_replicas': 0, '_num_worker_replicas': 1}
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1e68d990>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1e68d990>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1e68d990>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1e68d990>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1e68d990>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1e68d990>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Create CheckpointSaverHook.
    

    INFO:tensorflow:Create CheckpointSaverHook.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Saving checkpoints for 0 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt.
    

    INFO:tensorflow:Saving checkpoints for 0 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt.
    

    INFO:tensorflow:loss = 1.8196876, step = 1
    

    INFO:tensorflow:loss = 1.8196876, step = 1
    

    INFO:tensorflow:global_step/sec: 589.151
    

    INFO:tensorflow:global_step/sec: 589.151
    

    INFO:tensorflow:loss = 1.7542549, step = 101 (0.171 sec)
    

    INFO:tensorflow:loss = 1.7542549, step = 101 (0.171 sec)
    

    INFO:tensorflow:global_step/sec: 1275.67
    

    INFO:tensorflow:global_step/sec: 1275.67
    

    INFO:tensorflow:loss = 1.1477034, step = 201 (0.078 sec)
    

    INFO:tensorflow:loss = 1.1477034, step = 201 (0.078 sec)
    

    INFO:tensorflow:global_step/sec: 1240.18
    

    INFO:tensorflow:global_step/sec: 1240.18
    

    INFO:tensorflow:loss = 0.9699066, step = 301 (0.081 sec)
    

    INFO:tensorflow:loss = 0.9699066, step = 301 (0.081 sec)
    

    INFO:tensorflow:global_step/sec: 1633.32
    

    INFO:tensorflow:global_step/sec: 1633.32
    

    INFO:tensorflow:loss = 2.093548, step = 401 (0.061 sec)
    

    INFO:tensorflow:loss = 2.093548, step = 401 (0.061 sec)
    

    INFO:tensorflow:global_step/sec: 1666.97
    

    INFO:tensorflow:global_step/sec: 1666.97
    

    INFO:tensorflow:loss = 1.2313025, step = 501 (0.060 sec)
    

    INFO:tensorflow:loss = 1.2313025, step = 501 (0.060 sec)
    

    INFO:tensorflow:Saving checkpoints for 600 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt.
    

    INFO:tensorflow:Saving checkpoints for 600 into /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt.
    

    INFO:tensorflow:Loss for final step: 0.89184976.
    

    INFO:tensorflow:Loss for final step: 0.89184976.
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1fd23550>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1fd23550>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1fd23550>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1fd23550>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1fd23550>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1fd23550>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Starting evaluation at 2020-12-01T22:08:14Z
    

    INFO:tensorflow:Starting evaluation at 2020-12-01T22:08:14Z
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt-600
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt-600
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Evaluation [1/1]
    

    INFO:tensorflow:Evaluation [1/1]
    

    INFO:tensorflow:Finished evaluation at 2020-12-01-22:08:14
    

    INFO:tensorflow:Finished evaluation at 2020-12-01-22:08:14
    

    INFO:tensorflow:Saving dict for global step 600: average_loss = 1.0983461, covariance = [[[  93.92948 ]
      [1300.487   ]
      [  49.779022]
      [  72.566414]
      [ 382.24332 ]
      [  79.32507 ]
      [  57.019554]
      [  39.433468]
      [  42.636513]
      [  15.623931]
      [  35.514183]
      [  13.645474]
      [  42.636513]
      [  15.623931]
      [  55.85953 ]
      [  59.482327]
      [  47.181858]
      [  25.793745]
      [  39.041477]
      [  16.871897]
      [  47.181858]
      [  25.793745]
      [  35.514183]
      [  13.645474]
      [  36.733833]
      [  16.127363]
      [  36.733833]
      [  16.127363]
      [  35.514183]
      [  13.645474]
      [  37.995373]
      [  19.060663]
      [  51.187214]
      [  17.889244]
      [  46.528328]
      [  51.95009 ]
      [  44.983475]
      [  43.955334]
      [  58.97776 ]
      [  46.605766]
      [  42.636513]
      [  15.623931]
      [  51.86799 ]
      [  31.892582]
      [  40.382263]
      [  19.94062 ]
      [  52.21176 ]
      [  42.583225]
      [  48.80221 ]
      [  30.485205]
      [  42.9191  ]
      [  20.861195]
      [  36.733833]
      [  16.127363]
      [  36.733833]
      [  16.127363]
      [  37.745205]
      [  14.27543 ]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  49.815674]
      [  20.209991]
      [  44.687294]
      [  32.92022 ]
      [  48.80221 ]
      [  30.485205]
      [  41.769104]
      [  23.56749 ]
      [  35.514183]
      [  13.645474]
      [  36.733833]
      [  16.127363]
      [  36.733833]
      [  16.127363]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  36.733833]
      [  16.127363]
      [  37.745205]
      [  14.27543 ]
      [  41.494083]
      [  17.650803]
      [  41.494083]
      [  17.650803]
      [  40.382263]
      [  19.94062 ]
      [  56.644127]
      [  29.53358 ]
      [  41.769104]
      [  23.56749 ]
      [  44.393063]
      [  24.655504]
      [  39.041477]
      [  16.871897]
      [  48.48088 ]
      [  22.831808]
      [  47.181858]
      [  25.793745]
      [  45.615307]
      [  21.824268]
      [  35.514183]
      [  13.645474]
      [  41.769104]
      [  23.56749 ]
      [  37.995373]
      [  19.060663]
      [  37.745205]
      [  14.27543 ]
      [  42.636513]
      [  15.623931]
      [  53.64928 ]
      [  37.69332 ]
      [  50.47821 ]
      [  36.029964]
      [  45.31496 ]
      [  16.345224]
      [  42.9191  ]
      [  20.861195]
      [  35.514183]
      [  13.645474]
      [  37.745205]
      [  14.27543 ]
      [  44.100765]
      [  18.46567 ]
      [  47.181858]
      [  25.793745]
      [ 178.93912 ]
      [ 187.21793 ]
      [ 471.18954 ]
      [ 288.67395 ]
      [ 131.65778 ]
      [6915.977   ]
      [ 957.5229  ]
      [9648.868   ]
      [  75.75251 ]
      [  74.54024 ]
      [  57.820446]
      [  19.579117]
      [ 132.04599 ]
      [  41.607834]
      [ 163.61024 ]
      [2606.5151  ]
      [  46.528328]
      [  51.95009 ]
      [  99.97727 ]
      [ 105.52799 ]
      [  91.54736 ]
      [ 113.95707 ]
      [  62.682777]
      [  48.757366]
      [  83.276306]
      [  92.16501 ]
      [  40.649914]
      [  26.624868]
      [  35.514183]
      [  13.645474]
      [  44.983475]
      [  43.955334]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  37.995373]
      [  19.060663]
      [  41.494083]
      [  17.650803]
      [  42.9191  ]
      [  20.861195]
      [  37.745205]
      [  14.27543 ]
      [  37.995373]
      [  19.060663]
      [  42.9191  ]
      [  20.861195]
      [  35.514183]
      [  13.645474]
      [  37.745205]
      [  14.27543 ]
      [  40.11638 ]
      [  14.934468]
      [  37.995373]
      [  19.060663]
      [  41.494083]
      [  17.650803]
      [  40.382263]
      [  19.94062 ]
      [ 100.63991 ]
      [ 140.90178 ]
      [  89.68488 ]
      [ 171.8954  ]
      [ 107.6711  ]
      [ 196.8185  ]
      [  51.86799 ]
      [  31.892582]
      [  39.041477]
      [  16.871897]
      [  35.514183]
      [  13.645474]
      [  42.9191  ]
      [  20.861195]
      [  37.745205]
      [  14.27543 ]
      [  39.041477]
      [  16.871897]
      [  39.041477]
      [  16.871897]
      [  35.514183]
      [  13.645474]]], global_step = 600, loss = 1.0983461, mean = [[[10.3419485]
      [13.431444 ]
      [ 5.2042327]
      [ 6.18758  ]
      [15.959232 ]
      [11.844955 ]
      [ 5.535557 ]
      [ 5.3834248]
      [ 3.430796 ]
      [ 2.8254828]
      [ 2.3867595]
      [ 2.0738604]
      [ 3.430796 ]
      [ 2.8254828]
      [ 5.6847744]
      [ 6.116459 ]
      [ 4.2760377]
      [ 4.059599 ]
      [ 3.016519 ]
      [ 2.7357733]
      [ 4.2760377]
      [ 4.059599 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.9502542]
      [ 2.896604 ]
      [ 4.4748325]
      [ 3.5771055]
      [ 4.640738 ]
      [ 5.364836 ]
      [ 4.3589907]
      [ 4.953464 ]
      [ 5.817304 ]
      [ 5.7947965]
      [ 3.430796 ]
      [ 2.8254828]
      [ 4.9057975]
      [ 4.721512 ]
      [ 3.2982662]
      [ 3.1471453]
      [ 5.1212797]
      [ 5.2937145]
      [ 4.557785 ]
      [ 4.4709706]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 4.4085674]
      [ 3.7379367]
      [ 4.143508 ]
      [ 4.381261 ]
      [ 4.557785 ]
      [ 4.4709706]
      [ 3.5800138]
      [ 3.558517 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.2982662]
      [ 3.1471453]
      [ 5.320074 ]
      [ 4.8112216]
      [ 3.5800138]
      [ 3.558517 ]
      [ 3.9280257]
      [ 3.809058 ]
      [ 3.016519 ]
      [ 2.7357733]
      [ 4.342303 ]
      [ 3.8987677]
      [ 4.2760377]
      [ 4.059599 ]
      [ 3.9942906]
      [ 3.648227 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 3.5800138]
      [ 3.558517 ]
      [ 2.9502542]
      [ 2.896604 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.430796 ]
      [ 2.8254828]
      [ 5.187545 ]
      [ 5.1328835]
      [ 4.8395324]
      [ 4.882343 ]
      [ 3.778808 ]
      [ 3.076024 ]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.7125432]
      [ 3.236855 ]
      [ 4.2760377]
      [ 4.059599 ]
      [12.512487 ]
      [11.448938 ]
      [17.865202 ]
      [14.885391 ]
      [13.159422 ]
      [17.545164 ]
      [23.781897 ]
      [23.524202 ]
      [ 7.424835 ]
      [ 7.369163 ]
      [ 5.1708565]
      [ 4.0781875]
      [ 9.976762 ]
      [ 7.7465906]
      [13.689541 ]
      [16.258514 ]
      [ 4.640738 ]
      [ 5.364836 ]
      [ 9.098631 ]
      [ 8.782698 ]
      [ 8.684355 ]
      [ 8.692988 ]
      [ 6.1653166]
      [ 6.0453377]
      [ 8.054594 ]
      [ 8.0310755]
      [ 3.5137486]
      [ 3.7193482]
      [ 2.3867595]
      [ 2.0738604]
      [ 4.3589907]
      [ 4.953464 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.9502542]
      [ 2.896604 ]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 2.9502542]
      [ 2.896604 ]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.0827837]
      [ 2.5749424]
      [ 2.9502542]
      [ 2.896604 ]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.2982662]
      [ 3.1471453]
      [ 9.314114 ]
      [ 9.3549   ]
      [ 8.833571 ]
      [ 9.426023 ]
      [ 9.877607 ]
      [10.177645 ]
      [ 4.9057975]
      [ 4.721512 ]
      [ 3.016519 ]
      [ 2.7357733]
      [ 2.3867595]
      [ 2.0738604]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.016519 ]
      [ 2.7357733]
      [ 3.016519 ]
      [ 2.7357733]
      [ 2.3867595]
      [ 2.0738604]]], observed = [[[11.]
      [ 1.]
      [ 1.]
      [40.]
      [ 6.]
      [ 6.]
      [ 1.]
      [ 4.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 9.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 7.]
      [ 9.]
      [ 1.]
      [ 8.]
      [ 1.]
      [ 7.]
      [ 6.]
      [ 1.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 3.]
      [ 2.]
      [ 7.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 2.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 6.]
      [ 6.]
      [ 2.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 3.]
      [ 2.]
      [ 3.]
      [ 3.]
      [ 2.]
      [ 4.]
      [ 7.]
      [ 4.]
      [ 2.]
      [ 4.]
      [ 3.]
      [ 2.]
      [ 2.]
      [ 3.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 3.]
      [ 4.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 2.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 4.]
      [ 6.]
      [ 5.]
      [ 6.]
      [ 4.]
      [ 1.]
      [ 5.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 4.]
      [11.]
      [22.]
      [ 9.]
      [39.]
      [38.]
      [ 2.]
      [30.]
      [39.]
      [ 9.]
      [ 9.]
      [ 1.]
      [ 9.]
      [ 2.]
      [22.]
      [30.]
      [10.]
      [ 9.]
      [ 1.]
      [10.]
      [13.]
      [11.]
      [11.]
      [ 7.]
      [ 7.]
      [10.]
      [10.]
      [ 5.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 8.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 3.]
      [ 1.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 3.]
      [ 3.]
      [ 2.]
      [12.]
      [12.]
      [14.]
      [ 9.]
      [14.]
      [12.]
      [ 5.]
      [ 5.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]]], start_tuple = (array([[1506661200, 1506747600]]), array([[[-0.5422266],
            [-0.5422266]]], dtype=float32), array([], shape=(1, 2, 0), dtype=float32)), times = [[1488866400 1488952800 1489039200 1489125600 1489212000 1489298400
      1491109200 1491195600 1491368400 1491454800 1491714000 1491800400
      1491973200 1496466000 1496638800 1496725200 1496898000 1496984400
      1497157200 1497243600 1498971600 1499058000 1499230800 1499317200
      1499403600 1499490000 1499576400 1499662800 1499835600 1501563600
      1501650000 1501736400 1501822800 1501909200 1502082000 1502168400
      1502254800 1502341200 1502427600 1504242000 1504328400 1504414800
      1504501200 1504587600 1504674000 1504760400 1504846800 1504933200
      1505019600 1505106000 1505192400 1506834000 1506920400 1507006800
      1507179600 1507266000 1507352400 1507438800 1507611600 1507870800
      1507957200 1508043600 1508302800 1508389200 1508475600 1508562000
      1508648400 1508734800 1508821200 1508907600 1508994000 1509080400
      1509166800 1509253200 1509339600 1509598800 1509771600 1509858000
      1509948000 1510034400 1510120800 1510207200 1510293600 1510380000
      1510466400 1510552800 1510639200 1510725600 1510812000 1510898400
      1511071200 1511157600 1511244000 1511330400 1511416800 1511503200
      1511589600 1511676000 1511762400 1511848800 1511935200 1512021600
      1512108000 1512194400 1512280800 1512367200 1512453600 1512540000
      1512626400 1512712800 1512799200 1512885600 1512972000 1513058400
      1513144800 1513231200 1513317600 1513404000 1513490400 1513576800
      1513663200 1513749600 1513836000 1513922400 1514008800 1514095200
      1514181600 1514268000 1514354400 1487138400 1487397600 1489381200
      1489467600 1489554000 1489640400 1489726800 1489813200 1489899600
      1489986000 1490072400 1490158800 1490245200 1490331600 1490418000
      1490504400 1490677200 1490763600 1490850000 1492059600 1492146000
      1494651600 1494738000 1495256400 1495342800 1495688400 1495774800
      1497416400 1497848400 1497934800 1498107600 1498194000 1498280400
      1498453200 1498626000 1498712400 1499922000 1500008400 1500181200
      1500267600 1500354000 1500440400 1500613200 1500699600 1500872400
      1501045200 1501218000 1501304400 1501390800 1501477200 1502600400
      1502686800 1502773200 1502859600 1502946000 1503032400 1503118800
      1503205200 1503291600 1503378000 1503464400 1503550800 1503637200
      1503723600 1503810000 1503896400 1503982800 1504069200 1504155600
      1505278800 1505365200 1505451600 1505538000 1505624400 1505710800
      1505797200 1505883600 1505970000 1506056400 1506142800 1506402000
      1506488400 1506574800 1506661200 1506747600]]
    

    INFO:tensorflow:Saving dict for global step 600: average_loss = 1.0983461, covariance = [[[  93.92948 ]
      [1300.487   ]
      [  49.779022]
      [  72.566414]
      [ 382.24332 ]
      [  79.32507 ]
      [  57.019554]
      [  39.433468]
      [  42.636513]
      [  15.623931]
      [  35.514183]
      [  13.645474]
      [  42.636513]
      [  15.623931]
      [  55.85953 ]
      [  59.482327]
      [  47.181858]
      [  25.793745]
      [  39.041477]
      [  16.871897]
      [  47.181858]
      [  25.793745]
      [  35.514183]
      [  13.645474]
      [  36.733833]
      [  16.127363]
      [  36.733833]
      [  16.127363]
      [  35.514183]
      [  13.645474]
      [  37.995373]
      [  19.060663]
      [  51.187214]
      [  17.889244]
      [  46.528328]
      [  51.95009 ]
      [  44.983475]
      [  43.955334]
      [  58.97776 ]
      [  46.605766]
      [  42.636513]
      [  15.623931]
      [  51.86799 ]
      [  31.892582]
      [  40.382263]
      [  19.94062 ]
      [  52.21176 ]
      [  42.583225]
      [  48.80221 ]
      [  30.485205]
      [  42.9191  ]
      [  20.861195]
      [  36.733833]
      [  16.127363]
      [  36.733833]
      [  16.127363]
      [  37.745205]
      [  14.27543 ]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  49.815674]
      [  20.209991]
      [  44.687294]
      [  32.92022 ]
      [  48.80221 ]
      [  30.485205]
      [  41.769104]
      [  23.56749 ]
      [  35.514183]
      [  13.645474]
      [  36.733833]
      [  16.127363]
      [  36.733833]
      [  16.127363]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  36.733833]
      [  16.127363]
      [  37.745205]
      [  14.27543 ]
      [  41.494083]
      [  17.650803]
      [  41.494083]
      [  17.650803]
      [  40.382263]
      [  19.94062 ]
      [  56.644127]
      [  29.53358 ]
      [  41.769104]
      [  23.56749 ]
      [  44.393063]
      [  24.655504]
      [  39.041477]
      [  16.871897]
      [  48.48088 ]
      [  22.831808]
      [  47.181858]
      [  25.793745]
      [  45.615307]
      [  21.824268]
      [  35.514183]
      [  13.645474]
      [  41.769104]
      [  23.56749 ]
      [  37.995373]
      [  19.060663]
      [  37.745205]
      [  14.27543 ]
      [  42.636513]
      [  15.623931]
      [  53.64928 ]
      [  37.69332 ]
      [  50.47821 ]
      [  36.029964]
      [  45.31496 ]
      [  16.345224]
      [  42.9191  ]
      [  20.861195]
      [  35.514183]
      [  13.645474]
      [  37.745205]
      [  14.27543 ]
      [  44.100765]
      [  18.46567 ]
      [  47.181858]
      [  25.793745]
      [ 178.93912 ]
      [ 187.21793 ]
      [ 471.18954 ]
      [ 288.67395 ]
      [ 131.65778 ]
      [6915.977   ]
      [ 957.5229  ]
      [9648.868   ]
      [  75.75251 ]
      [  74.54024 ]
      [  57.820446]
      [  19.579117]
      [ 132.04599 ]
      [  41.607834]
      [ 163.61024 ]
      [2606.5151  ]
      [  46.528328]
      [  51.95009 ]
      [  99.97727 ]
      [ 105.52799 ]
      [  91.54736 ]
      [ 113.95707 ]
      [  62.682777]
      [  48.757366]
      [  83.276306]
      [  92.16501 ]
      [  40.649914]
      [  26.624868]
      [  35.514183]
      [  13.645474]
      [  44.983475]
      [  43.955334]
      [  35.514183]
      [  13.645474]
      [  35.514183]
      [  13.645474]
      [  37.995373]
      [  19.060663]
      [  41.494083]
      [  17.650803]
      [  42.9191  ]
      [  20.861195]
      [  37.745205]
      [  14.27543 ]
      [  37.995373]
      [  19.060663]
      [  42.9191  ]
      [  20.861195]
      [  35.514183]
      [  13.645474]
      [  37.745205]
      [  14.27543 ]
      [  40.11638 ]
      [  14.934468]
      [  37.995373]
      [  19.060663]
      [  41.494083]
      [  17.650803]
      [  40.382263]
      [  19.94062 ]
      [ 100.63991 ]
      [ 140.90178 ]
      [  89.68488 ]
      [ 171.8954  ]
      [ 107.6711  ]
      [ 196.8185  ]
      [  51.86799 ]
      [  31.892582]
      [  39.041477]
      [  16.871897]
      [  35.514183]
      [  13.645474]
      [  42.9191  ]
      [  20.861195]
      [  37.745205]
      [  14.27543 ]
      [  39.041477]
      [  16.871897]
      [  39.041477]
      [  16.871897]
      [  35.514183]
      [  13.645474]]], global_step = 600, loss = 1.0983461, mean = [[[10.3419485]
      [13.431444 ]
      [ 5.2042327]
      [ 6.18758  ]
      [15.959232 ]
      [11.844955 ]
      [ 5.535557 ]
      [ 5.3834248]
      [ 3.430796 ]
      [ 2.8254828]
      [ 2.3867595]
      [ 2.0738604]
      [ 3.430796 ]
      [ 2.8254828]
      [ 5.6847744]
      [ 6.116459 ]
      [ 4.2760377]
      [ 4.059599 ]
      [ 3.016519 ]
      [ 2.7357733]
      [ 4.2760377]
      [ 4.059599 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.9502542]
      [ 2.896604 ]
      [ 4.4748325]
      [ 3.5771055]
      [ 4.640738 ]
      [ 5.364836 ]
      [ 4.3589907]
      [ 4.953464 ]
      [ 5.817304 ]
      [ 5.7947965]
      [ 3.430796 ]
      [ 2.8254828]
      [ 4.9057975]
      [ 4.721512 ]
      [ 3.2982662]
      [ 3.1471453]
      [ 5.1212797]
      [ 5.2937145]
      [ 4.557785 ]
      [ 4.4709706]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 4.4085674]
      [ 3.7379367]
      [ 4.143508 ]
      [ 4.381261 ]
      [ 4.557785 ]
      [ 4.4709706]
      [ 3.5800138]
      [ 3.558517 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.668507 ]
      [ 2.485232 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.2982662]
      [ 3.1471453]
      [ 5.320074 ]
      [ 4.8112216]
      [ 3.5800138]
      [ 3.558517 ]
      [ 3.9280257]
      [ 3.809058 ]
      [ 3.016519 ]
      [ 2.7357733]
      [ 4.342303 ]
      [ 3.8987677]
      [ 4.2760377]
      [ 4.059599 ]
      [ 3.9942906]
      [ 3.648227 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 3.5800138]
      [ 3.558517 ]
      [ 2.9502542]
      [ 2.896604 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.430796 ]
      [ 2.8254828]
      [ 5.187545 ]
      [ 5.1328835]
      [ 4.8395324]
      [ 4.882343 ]
      [ 3.778808 ]
      [ 3.076024 ]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.7125432]
      [ 3.236855 ]
      [ 4.2760377]
      [ 4.059599 ]
      [12.512487 ]
      [11.448938 ]
      [17.865202 ]
      [14.885391 ]
      [13.159422 ]
      [17.545164 ]
      [23.781897 ]
      [23.524202 ]
      [ 7.424835 ]
      [ 7.369163 ]
      [ 5.1708565]
      [ 4.0781875]
      [ 9.976762 ]
      [ 7.7465906]
      [13.689541 ]
      [16.258514 ]
      [ 4.640738 ]
      [ 5.364836 ]
      [ 9.098631 ]
      [ 8.782698 ]
      [ 8.684355 ]
      [ 8.692988 ]
      [ 6.1653166]
      [ 6.0453377]
      [ 8.054594 ]
      [ 8.0310755]
      [ 3.5137486]
      [ 3.7193482]
      [ 2.3867595]
      [ 2.0738604]
      [ 4.3589907]
      [ 4.953464 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.9502542]
      [ 2.896604 ]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 2.9502542]
      [ 2.896604 ]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.3867595]
      [ 2.0738604]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.0827837]
      [ 2.5749424]
      [ 2.9502542]
      [ 2.896604 ]
      [ 3.364531 ]
      [ 2.986314 ]
      [ 3.2982662]
      [ 3.1471453]
      [ 9.314114 ]
      [ 9.3549   ]
      [ 8.833571 ]
      [ 9.426023 ]
      [ 9.877607 ]
      [10.177645 ]
      [ 4.9057975]
      [ 4.721512 ]
      [ 3.016519 ]
      [ 2.7357733]
      [ 2.3867595]
      [ 2.0738604]
      [ 3.6462784]
      [ 3.397686 ]
      [ 2.7347717]
      [ 2.3244011]
      [ 3.016519 ]
      [ 2.7357733]
      [ 3.016519 ]
      [ 2.7357733]
      [ 2.3867595]
      [ 2.0738604]]], observed = [[[11.]
      [ 1.]
      [ 1.]
      [40.]
      [ 6.]
      [ 6.]
      [ 1.]
      [ 4.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 9.]
      [ 4.]
      [ 4.]
      [ 4.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 7.]
      [ 9.]
      [ 1.]
      [ 8.]
      [ 1.]
      [ 7.]
      [ 6.]
      [ 1.]
      [ 4.]
      [ 5.]
      [ 5.]
      [ 3.]
      [ 2.]
      [ 7.]
      [ 4.]
      [ 5.]
      [ 4.]
      [ 3.]
      [ 3.]
      [ 2.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 6.]
      [ 6.]
      [ 2.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 3.]
      [ 2.]
      [ 3.]
      [ 3.]
      [ 2.]
      [ 4.]
      [ 7.]
      [ 4.]
      [ 2.]
      [ 4.]
      [ 3.]
      [ 2.]
      [ 2.]
      [ 3.]
      [ 5.]
      [ 4.]
      [ 4.]
      [ 3.]
      [ 4.]
      [ 1.]
      [ 1.]
      [ 4.]
      [ 2.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 4.]
      [ 6.]
      [ 5.]
      [ 6.]
      [ 4.]
      [ 1.]
      [ 5.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 4.]
      [ 4.]
      [ 4.]
      [11.]
      [22.]
      [ 9.]
      [39.]
      [38.]
      [ 2.]
      [30.]
      [39.]
      [ 9.]
      [ 9.]
      [ 1.]
      [ 9.]
      [ 2.]
      [22.]
      [30.]
      [10.]
      [ 9.]
      [ 1.]
      [10.]
      [13.]
      [11.]
      [11.]
      [ 7.]
      [ 7.]
      [10.]
      [10.]
      [ 5.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 8.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 3.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 3.]
      [ 1.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 2.]
      [ 1.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 3.]
      [ 3.]
      [ 2.]
      [12.]
      [12.]
      [14.]
      [ 9.]
      [14.]
      [12.]
      [ 5.]
      [ 5.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 3.]
      [ 3.]
      [ 1.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 2.]
      [ 1.]
      [ 1.]
      [ 1.]
      [ 1.]]], start_tuple = (array([[1506661200, 1506747600]]), array([[[-0.5422266],
            [-0.5422266]]], dtype=float32), array([], shape=(1, 2, 0), dtype=float32)), times = [[1488866400 1488952800 1489039200 1489125600 1489212000 1489298400
      1491109200 1491195600 1491368400 1491454800 1491714000 1491800400
      1491973200 1496466000 1496638800 1496725200 1496898000 1496984400
      1497157200 1497243600 1498971600 1499058000 1499230800 1499317200
      1499403600 1499490000 1499576400 1499662800 1499835600 1501563600
      1501650000 1501736400 1501822800 1501909200 1502082000 1502168400
      1502254800 1502341200 1502427600 1504242000 1504328400 1504414800
      1504501200 1504587600 1504674000 1504760400 1504846800 1504933200
      1505019600 1505106000 1505192400 1506834000 1506920400 1507006800
      1507179600 1507266000 1507352400 1507438800 1507611600 1507870800
      1507957200 1508043600 1508302800 1508389200 1508475600 1508562000
      1508648400 1508734800 1508821200 1508907600 1508994000 1509080400
      1509166800 1509253200 1509339600 1509598800 1509771600 1509858000
      1509948000 1510034400 1510120800 1510207200 1510293600 1510380000
      1510466400 1510552800 1510639200 1510725600 1510812000 1510898400
      1511071200 1511157600 1511244000 1511330400 1511416800 1511503200
      1511589600 1511676000 1511762400 1511848800 1511935200 1512021600
      1512108000 1512194400 1512280800 1512367200 1512453600 1512540000
      1512626400 1512712800 1512799200 1512885600 1512972000 1513058400
      1513144800 1513231200 1513317600 1513404000 1513490400 1513576800
      1513663200 1513749600 1513836000 1513922400 1514008800 1514095200
      1514181600 1514268000 1514354400 1487138400 1487397600 1489381200
      1489467600 1489554000 1489640400 1489726800 1489813200 1489899600
      1489986000 1490072400 1490158800 1490245200 1490331600 1490418000
      1490504400 1490677200 1490763600 1490850000 1492059600 1492146000
      1494651600 1494738000 1495256400 1495342800 1495688400 1495774800
      1497416400 1497848400 1497934800 1498107600 1498194000 1498280400
      1498453200 1498626000 1498712400 1499922000 1500008400 1500181200
      1500267600 1500354000 1500440400 1500613200 1500699600 1500872400
      1501045200 1501218000 1501304400 1501390800 1501477200 1502600400
      1502686800 1502773200 1502859600 1502946000 1503032400 1503118800
      1503205200 1503291600 1503378000 1503464400 1503550800 1503637200
      1503723600 1503810000 1503896400 1503982800 1504069200 1504155600
      1505278800 1505365200 1505451600 1505538000 1505624400 1505710800
      1505797200 1505883600 1505970000 1506056400 1506142800 1506402000
      1506488400 1506574800 1506661200 1506747600]]
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    WARNING:tensorflow:Skipping summary for start_tuple, must be a float, np.float32, np.int64, np.int32 or int or np.ndarray or a serialized string of Summary.
    

    WARNING:tensorflow:Skipping summary for start_tuple, must be a float, np.float32, np.int64, np.int32 or int or np.ndarray or a serialized string of Summary.
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Summary for np.ndarray is not visible in Tensorboard by default. Consider using a Tensorboard plugin for visualization (see https://github.com/tensorflow/tensorboard-plugin-example/blob/master/README.md for more information).
    

    INFO:tensorflow:Saving 'checkpoint_path' summary for global step 600: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt-600
    

    INFO:tensorflow:Saving 'checkpoint_path' summary for global step 600: /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt-600
    

    WARNING:tensorflow:Input graph does not use tf.data.Dataset or contain a QueueRunner. That means predict yields forever. This is probably a mistake.
    

    WARNING:tensorflow:Input graph does not use tf.data.Dataset or contain a QueueRunner. That means predict yields forever. This is probably a mistake.
    

    INFO:tensorflow:Calling model_fn.
    

    INFO:tensorflow:Calling model_fn.
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1ad02ad0>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1ad02ad0>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING:tensorflow:Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1ad02ad0>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1ad02ad0>>: AttributeError: module 'gast' has no attribute 'Index'
    

    WARNING: Entity <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1ad02ad0>> could not be transformed and will be executed as-is. Please report this to the AutgoGraph team. When filing the bug, set the verbosity to 10 (on Linux, `export AUTOGRAPH_VERBOSITY=10`) and attach the full output. Cause: converting <bound method FlatPredictionModel.call of <tensorflow.contrib.timeseries.python.timeseries.ar_model.FlatPredictionModel object at 0x7fbf1ad02ad0>>: AttributeError: module 'gast' has no attribute 'Index'
    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Done calling model_fn.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Graph was finalized.
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt-600
    

    INFO:tensorflow:Restoring parameters from /var/folders/xv/jcbrjhzs2cn3wh633pqxf63m0000gn/T/tmpi3d1htr4/model.ckpt-600
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    

    INFO:tensorflow:Done running local_init_op.
    


![png](output_36_98.png)

